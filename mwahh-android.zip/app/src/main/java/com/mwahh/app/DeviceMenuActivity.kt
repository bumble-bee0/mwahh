package com.mwahh.app

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.util.Locale

// Menu untuk satu perangkat: status + pilihan Kamera/Pantau layar/Kontrol HP/Lokasi/Saklar.
// Layar ini TIDAK menampilkan video sama sekali -- murni daftar, supaya saat video dibuka
// (FullscreenActivity) tampilannya benar-benar bersih tanpa tombol apapun yang menumpuk.
class DeviceMenuActivity : AppCompatActivity() {

    private val main = Handler(Looper.getMainLooper())
    private var code = ""
    private var devName = "HP"

    private var sig: Signaling? = null
    private var sigOn = false
    private var powerOn: Boolean? = null
    private var camOnline = false
    private var model = ""
    private var androidVer = ""
    private var level = -1
    private var charging = false
    private var batTs = 0L

    private var locLat: Double? = null
    private var locLng: Double? = null
    private var locAcc = -1.0
    private var locTs = 0L
    private var locStale = false
    private var locMsg = ""
    private var locPending = false

    private lateinit var tvHeader: TextView
    private lateinit var tvLoc: TextView
    private lateinit var btnPower: Button
    private lateinit var rowCam: LinearLayout
    private lateinit var rowScreen: LinearLayout
    private lateinit var rowControl: LinearLayout
    private lateinit var qLow: TextView
    private lateinit var qMid: TextView
    private lateinit var qHigh: TextView

    private val locTimeout = Runnable {
        if (locPending) {
            locPending = false
            locMsg = "tidak ada jawaban dari HP kedua"
            render()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            render()
            main.postDelayed(this, 30000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun menuRow(title: String, subtitle: String): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setBackgroundColor(0xFFEFEFEF.toInt())
        row.setPadding(dp(16), dp(14), dp(16), dp(14))
        row.isClickable = true
        row.isFocusable = true
        val t1 = TextView(this)
        t1.text = title
        t1.textSize = 17f
        t1.setTypeface(null, Typeface.BOLD)
        row.addView(t1)
        val t2 = TextView(this)
        t2.text = subtitle
        t2.textSize = 12f
        t2.setTextColor(0xFF555555.toInt())
        row.tag = t2
        row.addView(t2)
        return row
    }

    private fun setSub(row: LinearLayout, text: String) {
        (row.tag as? TextView)?.text = text
    }

    private fun qChip(label: String): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 12f
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(8), 0, dp(8))
        t.isClickable = true
        return t
    }

    private fun refreshQualityChips() {
        val cur = Cfg.quality(this)
        fun mark(t: TextView, q: String) {
            val on = cur == q
            t.setBackgroundColor(if (on) 0xFF2563EB.toInt() else 0xFFE5E5E5.toInt())
            t.setTextColor(if (on) 0xFFFFFFFF.toInt() else 0xFF333333.toInt())
        }
        mark(qLow, "low"); mark(qMid, "mid"); mark(qHigh, "high")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        code = intent.getStringExtra("code") ?: ""
        devName = intent.getStringExtra("name") ?: "HP"
        if (code.isEmpty()) {
            finish()
            return
        }
        title = devName

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(20), dp(20), dp(20))

        tvHeader = TextView(this)
        tvHeader.textSize = 14f
        box.addView(tvHeader)

        tvLoc = TextView(this)
        tvLoc.setTextColor(0xFF2563EB.toInt())
        tvLoc.textSize = 13f
        tvLoc.setPadding(0, dp(4), 0, dp(12))
        box.addView(tvLoc)

        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(10)

        rowCam = menuRow("Kamera", "")
        rowScreen = menuRow("Pantau layar", "lihat saja, tanpa kontrol")
        rowControl = menuRow("Kontrol HP", "bisa disentuh seperti HP biasa")
        box.addView(rowCam, lp)
        box.addView(rowScreen, lp)
        box.addView(rowControl, lp)

        val qLabel = TextView(this)
        qLabel.text = "Kualitas video"
        qLabel.textSize = 12f
        qLabel.setTextColor(0xFF777777.toInt())
        qLabel.setPadding(0, dp(4), 0, dp(4))
        box.addView(qLabel)

        val qRow = LinearLayout(this)
        qRow.orientation = LinearLayout.HORIZONTAL
        qLow = qChip("Hemat")
        qMid = qChip("Normal")
        qHigh = qChip("HD Tinggi")
        for (chip in listOf(qLow, qMid, qHigh)) {
            qRow.addView(chip, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        box.addView(qRow, lp)

        btnPower = Button(this)
        btnPower.isAllCaps = false
        box.addView(btnPower, lp)

        val rowLoc = menuRow("Lacak lokasi", "ketuk untuk mulai mencari")
        box.addView(rowLoc, lp)

        val sv = ScrollView(this)
        sv.addView(box, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(sv)

        rowCam.setOnClickListener { openFullscreen("cam") }
        rowScreen.setOnClickListener { openFullscreen("screen") }
        rowControl.setOnClickListener { openFullscreen("control") }
        rowLoc.setOnClickListener { locate() }
        qLow.setOnClickListener { Cfg.setQuality(this, "low"); refreshQualityChips() }
        qMid.setOnClickListener { Cfg.setQuality(this, "mid"); refreshQualityChips() }
        qHigh.setOnClickListener { Cfg.setQuality(this, "high"); refreshQualityChips() }
        refreshQualityChips()
        tvLoc.setOnClickListener { openMap() }
        btnPower.setOnClickListener {
            if (powerOn == false) sig?.send(Rtc.power(true)) else sig?.send(Rtc.power(false))
        }

        render()
    }

    override fun onStart() {
        super.onStart()
        sig = Signaling(this, code, { onMsg(it) }, { online ->
            sigOn = online
            if (!online) {
                powerOn = null
                camOnline = false
            }
            render()
        })
        sig?.start()
        main.post(ticker)
    }

    override fun onStop() {
        main.removeCallbacks(ticker)
        main.removeCallbacks(locTimeout)
        sig?.stop()
        sig = null
        sigOn = false
        camOnline = false
        powerOn = null
        locPending = false
        super.onStop()
    }

    private fun openFullscreen(kind: String) {
        if (!sigOn || camOnline != true || powerOn != true) {
            Toast.makeText(this, "HP kedua sedang offline atau koneksi diputus", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(
            Intent(this, FullscreenActivity::class.java)
                .putExtra("code", code)
                .putExtra("kind", kind)
                .putExtra("quality", Cfg.quality(this))
        )
    }

    private fun locate() {
        if (!sigOn || !camOnline) {
            Toast.makeText(this, "HP kedua sedang offline", Toast.LENGTH_SHORT).show()
            return
        }
        locPending = true
        locMsg = ""
        sig?.send(Rtc.cmd("locate"))
        main.removeCallbacks(locTimeout)
        main.postDelayed(locTimeout, 45000)
        render()
    }

    private fun fmt(d: Double) = String.format(Locale.US, "%.6f", d)

    private fun openMap() {
        val lat = locLat ?: return
        val lng = locLng ?: return
        val geo = android.net.Uri.parse("geo:${fmt(lat)},${fmt(lng)}?q=${fmt(lat)},${fmt(lng)}(${android.net.Uri.encode(devName)})")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, geo))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://maps.google.com/?q=${fmt(lat)},${fmt(lng)}")))
            } catch (e2: Exception) {
            }
        }
    }

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "power" -> powerOn = j.optBoolean("on", true)
            "peer" -> camOnline = j.optBoolean("online")
            "battery" -> {
                level = j.optInt("level", -1)
                charging = j.optBoolean("charging")
                batTs = j.optLong("ts", System.currentTimeMillis())
            }
            "info" -> {
                model = j.optString("model")
                androidVer = j.optString("android")
            }
            "loc" -> {
                locPending = false
                main.removeCallbacks(locTimeout)
                if (j.has("error")) {
                    locMsg = j.optString("error")
                } else {
                    locLat = j.optDouble("lat")
                    locLng = j.optDouble("lng")
                    locAcc = j.optDouble("acc", -1.0)
                    locTs = j.optLong("ts", System.currentTimeMillis())
                    locStale = j.optBoolean("stale")
                    locMsg = ""
                }
            }
        }
        render()
    }

    private fun ago(ts: Long): String {
        if (ts == 0L) return ""
        val m = (System.currentTimeMillis() - ts) / 60000
        return when {
            m < 1 -> "baru saja"
            m < 60 -> "$m mnt lalu"
            else -> "${m / 60} jam lalu"
        }
    }

    private fun render() {
        if (!::tvHeader.isInitialized) return
        val title = StringBuilder(devName)
        if (model.isNotEmpty()) title.append(" • ").append(model)
        if (androidVer.isNotEmpty()) title.append(" • Android ").append(androidVer)

        val status = when {
            !sigOn -> "Menyambung ke server…"
            powerOn == false -> "Koneksi diputus • kamera/layar dikunci"
            !camOnline -> "HP kedua offline"
            else -> "HP kedua online"
        }
        val bat = if (level >= 0) {
            "Baterai: $level%${if (charging) " • mengisi" else ""} • ${ago(batTs)}"
        } else {
            "Baterai: belum ada data"
        }
        tvHeader.text = "$title\n$status\n$bat"

        val lat = locLat
        val lng = locLng
        tvLoc.text = when {
            locPending -> "Lokasi: mencari…"
            locMsg.isNotEmpty() -> "Lokasi: $locMsg"
            lat != null && lng != null -> {
                val acc = if (locAcc >= 0) " (±${locAcc.toInt()} m)" else ""
                val old = if (locStale) " • terakhir diketahui" else ""
                "Lokasi: ${fmt(lat)}, ${fmt(lng)}$acc • ${ago(locTs)}$old — ketuk untuk buka peta"
            }
            else -> "Lokasi: belum dilacak"
        }

        val ready = sigOn && powerOn == true && camOnline
        for (r in listOf(rowCam, rowScreen, rowControl)) {
            r.alpha = if (ready) 1f else 0.4f
        }
        btnPower.isEnabled = sigOn && powerOn != null
        btnPower.text = if (powerOn == false) "Mulai" else "Putuskan"
    }
}
