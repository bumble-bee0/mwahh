package com.mwahh.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.util.Locale

// Menu satu perangkat: status, Kamera, Galeri, Lacak lokasi (langsung buka Google Maps),
// kualitas video, saklar Mulai/Putuskan, dan Lepas pasangan.
// Layar ini tidak menampilkan video; video ada di FullscreenActivity.
class DeviceMenuActivity : AppCompatActivity() {

    private val main = Handler(Looper.getMainLooper())
    private var code = ""
    private var devName = "HP"

    private var sig: Signaling? = null
    private var sigOn = false
    private var powerOn: Boolean? = null
    private var camOnline = false
    private var model = ""
    private var androidVer = ""
    private var level = -1
    private var charging = false
    private var batTs = 0L

    private var locLat: Double? = null
    private var locLng: Double? = null
    private var locAcc = -1.0
    private var locTs = 0L
    private var locStale = false
    private var locMsg = ""
    private var locPending = false
    private var openMapAfterRender = false

    private lateinit var tvTitle: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvBattery: TextView
    private lateinit var tvCode: TextView
    private lateinit var tvLoc: TextView
    private lateinit var dotStatus: android.view.View
    private lateinit var btnCam: TextView
    private lateinit var btnGallery: TextView
    private lateinit var btnLocate: TextView
    private lateinit var btnPower: TextView
    private lateinit var qLow: TextView
    private lateinit var qMid: TextView
    private lateinit var qHigh: TextView

    private val locTimeout = Runnable {
        if (locPending) {
            locPending = false
            locMsg = "tidak ada jawaban dari HP kedua"
            render()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            render()
            main.postDelayed(this, 30000)
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun qChip(label: String): TextView {
        val t = Ui.text(this, label, 13f, Ui.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(10), 0, dp(10))
        t.isClickable = true
        return t
    }

    private fun refreshQualityChips() {
        val cur = Cfg.quality(this)
        fun mark(t: TextView, q: String) {
            val on = cur == q
            t.background = Ui.rounded(this, if (on) Ui.ACCENT else Ui.CHIP_OFF, 10)
            t.setTextColor(if (on) 0xFFFFFFFF.toInt() else Ui.TEXT)
        }
        mark(qLow, "low"); mark(qMid, "mid"); mark(qHigh, "high")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        code = intent.getStringExtra("code") ?: ""
        devName = intent.getStringExtra("name") ?: "HP"
        if (code.isEmpty()) {
            finish()
            return
        }
        title = devName

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(36), dp(18), dp(24))

        val back = Ui.text(this, "‹ Kembali", 15f, Ui.ACCENT, true)
        back.setPadding(0, 0, 0, dp(10))
        back.setOnClickListener { finish() }
        box.addView(back)

        // Kartu status
        val st = Ui.card(this)
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        dotStatus = Ui.dot(this, Ui.GRAY)
        val dotLp = LinearLayout.LayoutParams(dp(10), dp(10))
        dotLp.rightMargin = dp(10)
        top.addView(dotStatus, dotLp)
        tvTitle = Ui.text(this, devName, 20f, Ui.TEXT, true)
        top.addView(tvTitle)
        st.addView(top)
        tvStatus = Ui.text(this, "", 14f, Ui.SUB, true)
        tvStatus.setPadding(dp(20), dp(2), 0, 0)
        st.addView(tvStatus)
        tvBattery = Ui.text(this, "", 14f, Ui.TEXT)
        tvBattery.setPadding(dp(20), dp(6), 0, 0)
        st.addView(tvBattery)
        tvCode = Ui.text(this, "Kode: $code  (ketuk untuk salin)", 12f, Ui.SUB)
        tvCode.setPadding(dp(20), dp(8), 0, 0)
        tvCode.setOnClickListener { copyCode() }
        st.addView(tvCode)
        box.addView(st, Ui.lpMatch(this, 12))

        // Aksi utama
        btnCam = Ui.button(this, "Buka kamera", true)
        box.addView(btnCam, Ui.lpMatch(this, 10))
        btnGallery = Ui.button(this, "Galeri HP kedua", false)
        box.addView(btnGallery, Ui.lpMatch(this, 10))

        // Lokasi
        val locCard = Ui.card(this)
        btnLocate = Ui.button(this, "Lacak lokasi (buka Google Maps)", false)
        locCard.addView(btnLocate, Ui.lpMatch(this, 8))
        tvLoc = Ui.text(this, "", 13f, Ui.SUB)
        locCard.addView(tvLoc)
        box.addView(locCard, Ui.lpMatch(this, 12))

        // Kualitas video
        val qCard = Ui.card(this)
        qCard.addView(Ui.text(this, "Kualitas video", 13f, Ui.SUB), Ui.lpMatch(this, 8))
        val qRow = LinearLayout(this)
        qRow.orientation = LinearLayout.HORIZONTAL
        qLow = qChip("Hemat")
        qMid = qChip("Normal")
        qHigh = qChip("HD Tinggi")
        for (chip in listOf(qLow, qMid, qHigh)) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.rightMargin = dp(6)
            qRow.addView(chip, lp)
        }
        qCard.addView(qRow)
        box.addView(qCard, Ui.lpMatch(this, 12))

        // Pengaturan
        btnPower = Ui.button(this, "Putuskan", false)
        box.addView(btnPower, Ui.lpMatch(this, 10))
        val btnUnbind = Ui.button(this, "Lepas pasangan HP kedua", false)
        box.addView(btnUnbind, Ui.lpMatch(this, 6))
        val unbindNote = Ui.text(this, "Pakai ini kalau HP kedua diganti. Kode yang sama lalu bisa dipasang di HP lain.", 12f, Ui.SUB)
        unbindNote.setPadding(dp(4), 0, 0, 0)
        box.addView(unbindNote)

        val sv = ScrollView(this)
        sv.addView(box, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(sv)

        btnCam.setOnClickListener { openFullscreen() }
        btnGallery.setOnClickListener { openGallery() }
        btnLocate.setOnClickListener { locate() }
        tvLoc.setOnClickListener { openMap() }
        qLow.setOnClickListener { Cfg.setQuality(this, "low"); refreshQualityChips() }
        qMid.setOnClickListener { Cfg.setQuality(this, "mid"); refreshQualityChips() }
        qHigh.setOnClickListener { Cfg.setQuality(this, "high"); refreshQualityChips() }
        refreshQualityChips()
        btnPower.setOnClickListener {
            if (powerOn == null) return@setOnClickListener
            sig?.send(Rtc.power(powerOn == false))
        }
        btnUnbind.setOnClickListener { unbindDialog() }

        render()
    }

    override fun onStart() {
        super.onStart()
        sig = Signaling(this, code, { onMsg(it) }, { online ->
            sigOn = online
            if (!online) {
                powerOn = null
                camOnline = false
            }
            render()
        })
        sig?.start()
        main.post(ticker)
    }

    override fun onStop() {
        main.removeCallbacks(ticker)
        main.removeCallbacks(locTimeout)
        sig?.stop()
        sig = null
        sigOn = false
        camOnline = false
        powerOn = null
        locPending = false
        super.onStop()
    }

    private fun copyCode() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("kode", code))
        Toast.makeText(this, "Kode disalin", Toast.LENGTH_SHORT).show()
    }

    private fun unbindDialog() {
        AlertDialog.Builder(this)
            .setTitle("Lepas pasangan?")
            .setMessage("HP kedua yang terpasang akan diputus dan dikeluarkan. Setelah ini kode bisa dipasang di HP lain.")
            .setPositiveButton("Lepas") { _, _ ->
                Thread {
                    val r = Api.request(Cfg.unbindUrl(this, code))
                    main.post {
                        val msg = if (r.code == 200) "Pasangan dilepas" else "Gagal melepas (kode ${r.code})"
                        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun openGallery() {
        // Galeri tidak terikat saklar Mulai/Putuskan, cukup HP kedua online.
        if (!sigOn || !camOnline) {
            Toast.makeText(this, "HP kedua sedang offline", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, GalleryActivity::class.java).putExtra("code", code))
    }

    private fun openFullscreen() {
        if (!sigOn || !camOnline || powerOn != true) {
            Toast.makeText(this, "HP kedua sedang offline atau koneksi diputus", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(
            Intent(this, FullscreenActivity::class.java)
                .putExtra("code", code)
                .putExtra("quality", Cfg.quality(this))
        )
    }

    private fun locate() {
        if (!sigOn || !camOnline) {
            Toast.makeText(this, "HP kedua sedang offline", Toast.LENGTH_SHORT).show()
            return
        }
        locPending = true
        locMsg = ""
        sig?.send(Rtc.cmd("locate"))
        main.removeCallbacks(locTimeout)
        main.postDelayed(locTimeout, 45000)
        render()
    }

    private fun fmt(d: Double) = String.format(Locale.US, "%.6f", d)

    // Buka titik lokasi langsung di Google Maps (atau aplikasi peta lain kalau Maps tidak ada).
    private fun openMap() {
        val lat = locLat ?: return
        val lng = locLng ?: return
        val label = Uri.encode(devName)
        val geo = Uri.parse("geo:${fmt(lat)},${fmt(lng)}?q=${fmt(lat)},${fmt(lng)}($label)")
        val intent = Intent(Intent.ACTION_VIEW, geo)
        intent.setPackage("com.google.android.apps.maps")
        try {
            startActivity(intent)
        } catch (e: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=${fmt(lat)},${fmt(lng)}")))
            } catch (e2: Exception) {
                Toast.makeText(this, "Tidak ada aplikasi peta", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "power" -> powerOn = j.optBoolean("on", true)
            "peer" -> camOnline = j.optBoolean("online")
            "battery" -> {
                level = j.optInt("level", -1)
                charging = j.optBoolean("charging")
                batTs = j.optLong("ts", System.currentTimeMillis())
            }
            "info" -> {
                model = j.optString("model")
                androidVer = j.optString("android")
            }
            "loc" -> {
                val wasPending = locPending
                locPending = false
                main.removeCallbacks(locTimeout)
                if (j.has("error")) {
                    locMsg = j.optString("error").ifEmpty { "lokasi gagal didapat" }
                } else {
                    val la = j.optDouble("lat")
                    val ln = j.optDouble("lng")
                    if (la.isNaN() || ln.isNaN()) {
                        locMsg = "data lokasi dari HP kedua tidak valid"
                    } else {
                        locLat = la
                        locLng = ln
                        locAcc = j.optDouble("acc", -1.0)
                        locTs = j.optLong("ts", System.currentTimeMillis())
                        locStale = j.optBoolean("stale")
                        locMsg = ""
                        // Hasil baru dari permintaan kita: langsung ke Google Maps.
                        // Lokasi lama (stale) atau kiriman otomatis saat tersambung tidak membuka peta.
                        if (wasPending && !locStale) openMapAfterRender = true
                    }
                }
            }
        }
        render()
        if (openMapAfterRender) {
            openMapAfterRender = false
            openMap()
        }
    }

    private fun render() {
        if (!::tvTitle.isInitialized) return
        val title = StringBuilder(devName)
        if (model.isNotEmpty()) title.append(" • ").append(model)
        tvTitle.text = title.toString()

        val (statusText, statusColor) = when {
            !sigOn -> Pair("Menyambung ke server…", Ui.GRAY)
            powerOn == false -> Pair("Koneksi diputus • kamera/layar dikunci", Ui.WARN)
            !camOnline -> Pair("HP kedua offline", Ui.BAD)
            else -> Pair("HP kedua online", Ui.GOOD)
        }
        tvStatus.text = statusText + if (androidVer.isNotEmpty()) " • Android $androidVer" else ""
        tvStatus.setTextColor(statusColor)
        (dotStatus.background as? android.graphics.drawable.GradientDrawable)?.setColor(statusColor)

        tvBattery.text = if (level >= 0) {
            "Baterai $level%${if (charging) " • mengisi" else ""} • ${Ui.ago(batTs)}"
        } else {
            "Baterai: belum ada data"
        }
        tvBattery.setTextColor(if (level in 0..15 && !charging) Ui.BAD else Ui.TEXT)

        val lat = locLat
        val lng = locLng
        val last = if (lat != null && lng != null) {
            val acc = if (locAcc >= 0) " (±${locAcc.toInt()} m)" else ""
            val old = if (locStale) " • terakhir diketahui" else ""
            "${fmt(lat)}, ${fmt(lng)}$acc • ${Ui.ago(locTs)}$old"
        } else null
        tvLoc.text = when {
            locPending -> "Mencari lokasi… (bisa sampai 45 detik)"
            locMsg.isNotEmpty() && last != null -> "Gagal: $locMsg\nLokasi terakhir: $last — ketuk untuk buka di Google Maps"
            locMsg.isNotEmpty() -> "Gagal: $locMsg"
            last != null -> "Lokasi terakhir: $last — ketuk untuk buka di Google Maps"
            else -> "Belum pernah dilacak."
        }
        btnLocate.alpha = if (sigOn && camOnline && !locPending) 1f else 0.4f

        val ready = sigOn && powerOn == true && camOnline
        btnCam.alpha = if (ready) 1f else 0.4f
        btnGallery.alpha = if (sigOn && camOnline) 1f else 0.4f
        btnPower.alpha = if (sigOn && powerOn != null) 1f else 0.4f
        btnPower.text = if (powerOn == false) "Mulai (sambungkan lagi)" else "Putuskan"
    }
}
