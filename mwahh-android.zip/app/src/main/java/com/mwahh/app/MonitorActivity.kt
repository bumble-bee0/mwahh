package com.mwahh.app

import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.*
import org.webrtc.audio.JavaAudioDeviceModule
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs

// Satu perangkat: tampilan kamera/layar + saklar + lacak lokasi + kontrol sentuh.
class MonitorActivity : AppCompatActivity() {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var video: SurfaceViewRenderer
    private lateinit var tvStatus: TextView
    private lateinit var tvLoc: TextView
    private lateinit var btnPower: Button
    private lateinit var btnToggle: Button
    private lateinit var btnSwitch: Button
    private lateinit var btnMute: Button
    private lateinit var btnLocate: Button
    private lateinit var btnKindCam: Button
    private lateinit var btnKindScreen: Button
    private lateinit var btnKindControl: Button
    private lateinit var navBar: LinearLayout
    private lateinit var btnHome: Button
    private lateinit var btnBack: Button
    private lateinit var btnRecents: Button

    private var code = ""
    private var devName = "HP"

    private var sig: Signaling? = null
    private var egl: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private val ice = IceQueue()
    private var lastIce: JSONArray? = null
    private var remoteVideo: VideoTrack? = null
    private var remoteAudio: AudioTrack? = null

    private var sigOn = false
    private var powerOn: Boolean? = null
    private var camOnline = false
    private var camStreaming = false
    private var connecting = false
    private var facing = "back"
    private var level = -1
    private var charging = false
    private var batTs = 0L
    private var muted = false

    // "cam" = kamera CCTV, "screen" = pantau layar (lihat saja), "control" = kontrol penuh.
    private var wantKind = "cam"
    private var activeKind = "cam"
    private var remoteW = 0
    private var remoteH = 0

    private var model = ""
    private var androidVer = ""

    private var locLat: Double? = null
    private var locLng: Double? = null
    private var locAcc = -1.0
    private var locTs = 0L
    private var locStale = false
    private var locMsg = ""
    private var locPending = false

    private val locTimeout = Runnable {
        if (locPending) {
            locPending = false
            locMsg = "tidak ada jawaban dari HP kedua"
            render()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            render()
            main.postDelayed(this, 30000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun row(vararg bs: Button): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (b in bs) {
            b.isAllCaps = false
            r.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        return r
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        code = intent.getStringExtra("code") ?: ""
        devName = intent.getStringExtra("name") ?: "HP"
        if (code.isEmpty()) {
            finish()
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        volumeControlStream = AudioManager.STREAM_VOICE_CALL

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF000000.toInt())

        video = SurfaceViewRenderer(this)
        root.addView(video, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.VERTICAL
        top.setBackgroundColor(0x99000000.toInt())
        tvStatus = TextView(this)
        tvStatus.setTextColor(0xFFFFFFFF.toInt())
        tvStatus.setPadding(dp(14), dp(12), dp(14), dp(4))
        tvStatus.textSize = 14f
        tvLoc = TextView(this)
        tvLoc.setTextColor(0xFF9CD3FF.toInt())
        tvLoc.setPadding(dp(14), dp(4), dp(14), dp(12))
        tvLoc.textSize = 13f
        top.addView(tvStatus)
        top.addView(tvLoc)
        val topLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        topLp.gravity = Gravity.TOP
        root.addView(top, topLp)

        btnPower = Button(this)
        btnToggle = Button(this)
        btnSwitch = Button(this)
        btnMute = Button(this)
        btnLocate = Button(this)
        btnKindCam = Button(this)
        btnKindScreen = Button(this)
        btnKindControl = Button(this)
        btnHome = Button(this)
        btnBack = Button(this)
        btnRecents = Button(this)
        btnSwitch.text = "Ganti kamera"
        btnLocate.text = "Lacak lokasi"
        btnKindCam.text = "Kamera"
        btnKindScreen.text = "Pantau layar"
        btnKindControl.text = "Kontrol HP"
        btnHome.text = "Home"
        btnBack.text = "Back"
        btnRecents.text = "Recents"

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        bar.setBackgroundColor(0x99000000.toInt())
        bar.setPadding(dp(8), dp(8), dp(8), dp(8))
        bar.addView(row(btnKindCam, btnKindScreen, btnKindControl))
        bar.addView(row(btnPower, btnToggle))
        bar.addView(row(btnSwitch, btnMute, btnLocate))
        navBar = row(btnHome, btnBack, btnRecents)
        navBar.visibility = View.GONE
        bar.addView(navBar)
        val botLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        botLp.gravity = Gravity.BOTTOM
        root.addView(bar, botLp)
        setContentView(root)

        btnKindCam.setOnClickListener { chooseKind("cam") }
        btnKindScreen.setOnClickListener { chooseKind("screen") }
        btnKindControl.setOnClickListener { chooseKind("control") }

        btnPower.setOnClickListener {
            if (powerOn == false) {
                sig?.send(Rtc.power(true))
            } else {
                if (camStreaming || connecting) {
                    sig?.send(Rtc.cmd("stop"))
                    teardownPc()
                    camStreaming = false
                    connecting = false
                }
                sig?.send(Rtc.power(false))
            }
            render()
        }
        btnToggle.setOnClickListener {
            if (camStreaming || connecting) {
                sig?.send(Rtc.cmd("stop"))
                teardownPc()
                camStreaming = false
                connecting = false
            } else {
                connecting = true
                startCamera()
            }
            render()
        }
        btnSwitch.setOnClickListener {
            sig?.send(Rtc.cmd("switch"))
        }
        btnMute.setOnClickListener {
            muted = !muted
            remoteAudio?.setEnabled(!muted)
            render()
        }
        btnLocate.setOnClickListener {
            if (!sigOn || !camOnline) {
                Toast.makeText(this, "HP kedua sedang offline", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            locPending = true
            locMsg = ""
            sig?.send(Rtc.cmd("locate"))
            main.removeCallbacks(locTimeout)
            main.postDelayed(locTimeout, 45000)
            render()
        }
        btnHome.setOnClickListener { sendKey("home") }
        btnBack.setOnClickListener { sendKey("back") }
        btnRecents.setOnClickListener { sendKey("recents") }
        tvLoc.setOnClickListener { openMap() }

        setupTouch()
        render()
    }

    override fun onStart() {
        super.onStart()
        if (code.isEmpty()) return
        val e = EglBase.create()
        egl = e
        video.init(e.eglBaseContext, null)
        video.setEnableHardwareScaler(true)
        sig = Signaling(this, code, { onMsg(it) }, { online ->
            sigOn = online
            if (!online) {
                powerOn = null
                camOnline = false
                camStreaming = false
                connecting = false
                teardownPc()
            }
            render()
        })
        sig?.start()
        main.post(ticker)
    }

    override fun onStop() {
        if (code.isNotEmpty()) {
            main.removeCallbacks(ticker)
            main.removeCallbacks(locTimeout)
            // Menutup tampilan = kamera/layar HP kedua ikut mati.
            if (camStreaming || connecting) sig?.send(Rtc.cmd("stop"))
            sig?.stop()
            sig = null
            teardownPc()
            camStreaming = false
            connecting = false
            sigOn = false
            camOnline = false
            powerOn = null
            locPending = false
            video.release()
            egl?.release()
            egl = null
        }
        super.onStop()
    }

    private fun chooseKind(k: String) {
        if (wantKind == k) return
        wantKind = k
        if (camStreaming || connecting) {
            // Pindah mode: tutup dulu, nyalakan ulang dengan mode baru.
            sig?.send(Rtc.cmd("stop"))
            teardownPc()
            camStreaming = false
            connecting = true
            startCamera()
        }
        render()
    }

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "power" -> {
                powerOn = j.optBoolean("on", true)
                if (powerOn == false) {
                    camStreaming = false
                    connecting = false
                    teardownPc()
                }
            }
            "peer" -> {
                camOnline = j.optBoolean("online")
                if (!camOnline) {
                    camStreaming = false
                    connecting = false
                    teardownPc()
                }
            }
            "battery" -> {
                level = j.optInt("level", -1)
                charging = j.optBoolean("charging")
                batTs = j.optLong("ts", System.currentTimeMillis())
            }
            "info" -> {
                model = j.optString("model")
                androidVer = j.optString("android")
            }
            "error" -> {
                connecting = false
                Toast.makeText(this, j.optString("message", "Terjadi kesalahan"), Toast.LENGTH_LONG).show()
            }
            "loc" -> {
                locPending = false
                main.removeCallbacks(locTimeout)
                if (j.has("error")) {
                    locMsg = j.optString("error")
                } else {
                    locLat = j.optDouble("lat")
                    locLng = j.optDouble("lng")
                    locAcc = j.optDouble("acc", -1.0)
                    locTs = j.optLong("ts", System.currentTimeMillis())
                    locStale = j.optBoolean("stale")
                    locMsg = ""
                }
            }
            "state" -> {
                camStreaming = j.optBoolean("streaming")
                activeKind = j.optString("kind", "cam")
                facing = j.optString("facing", facing)
                remoteW = j.optInt("w", 0)
                remoteH = j.optInt("h", 0)
                if (!camStreaming) {
                    connecting = false
                    teardownPc()
                }
            }
            "offer" -> handleOffer(j.getString("sdp"))
            "ice" -> {
                try { ice.add(pc, Rtc.jsonToIce(j)) } catch (e: Exception) {}
            }
        }
        render()
    }

    private fun fmt(d: Double) = String.format(Locale.US, "%.6f", d)

    private fun openMap() {
        val lat = locLat ?: return
        val lng = locLng ?: return
        val geo = Uri.parse("geo:${fmt(lat)},${fmt(lng)}?q=${fmt(lat)},${fmt(lng)}(${Uri.encode(devName)})")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, geo))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=${fmt(lat)},${fmt(lng)}"))
                )
            } catch (e2: Exception) {
            }
        }
    }

    // Ambil daftar ICE (STUN/TURN) di sini, lalu dikirim ke HP kedua bersama perintah mulai.
    private fun startCamera() {
        val k = wantKind
        Thread {
            val arr = fetchIceJson()
            main.post {
                if (!connecting || sig == null || wantKind != k) return@post
                lastIce = arr
                sig?.send(Rtc.cmd("start").put("ice", arr).put("kind", k))
            }
        }.start()
    }

    private fun fetchIceJson(): JSONArray {
        val fb = JSONArray().put(
            JSONObject().put("urls", JSONArray().put("stun:stun.cloudflare.com:3478"))
        )
        return try {
            val client = OkHttpClient.Builder().callTimeout(8, TimeUnit.SECONDS).build()
            val req = Request.Builder().url(Cfg.turnUrl(this)).build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) {
                    fb
                } else {
                    val root = JSONObject(r.body!!.string())
                    when (val raw = root.opt("iceServers")) {
                        is JSONArray -> raw
                        is JSONObject -> JSONArray().put(raw)
                        else -> fb
                    }
                }
            }
        } catch (e: Exception) {
            fb
        }
    }

    private fun handleOffer(sdp: String) {
        teardownPc()
        try {
            answer(Rtc.toIceServers(lastIce), sdp)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun answer(servers: List<PeerConnection.IceServer>, sdp: String) {
        val eglB = egl ?: return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .createInitializationOptions()
        )
        val adm = JavaAudioDeviceModule.builder(this).createAudioDeviceModule()
        val f = PeerConnectionFactory.builder()
            .setAudioDeviceModule(adm)
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglB.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglB.eglBaseContext))
            .createPeerConnectionFactory()
        adm.release()
        factory = f

        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = true

        val cfg = PeerConnection.RTCConfiguration(servers)
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val p = f.createPeerConnection(cfg, object : Rtc.PcObserver() {
            override fun onIceCandidate(c: IceCandidate?) {
                if (c != null) main.post { sig?.send(Rtc.iceToJson(c)) }
            }

            override fun onTrack(transceiver: RtpTransceiver?) {
                val tr = transceiver?.receiver?.track() ?: return
                main.post {
                    when (tr) {
                        is VideoTrack -> {
                            remoteVideo = tr
                            tr.addSink(video)
                        }
                        is AudioTrack -> {
                            remoteAudio = tr
                            tr.setEnabled(!muted)
                        }
                    }
                }
            }

            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                if (s == PeerConnection.IceConnectionState.FAILED) {
                    main.post {
                        sig?.send(Rtc.cmd("stop"))
                        teardownPc()
                        camStreaming = false
                        connecting = false
                        render()
                        Toast.makeText(
                            this@MonitorActivity,
                            "Video gagal tersambung (jaringan mungkin butuh TURN)",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }) ?: throw IllegalStateException("peer connection gagal dibuat")
        pc = p
        ice.reset()

        p.setRemoteDescription(object : Rtc.Sdp() {
            override fun onSetSuccess() {
                main.post {
                    if (pc !== p) return@post
                    ice.flush(p)
                    p.createAnswer(object : Rtc.Sdp() {
                        override fun onCreateSuccess(d: SessionDescription?) {
                            if (d == null) return
                            p.setLocalDescription(Rtc.Sdp(), d)
                            main.post {
                                sig?.send(JSONObject().put("type", "answer").put("sdp", d.description))
                            }
                        }
                    }, MediaConstraints())
                }
            }
        }, SessionDescription(SessionDescription.Type.OFFER, sdp))
    }

    private fun teardownPc() {
        try { remoteVideo?.removeSink(video) } catch (e: Exception) {}
        remoteVideo = null
        remoteAudio = null
        try { pc?.close() } catch (e: Exception) {}
        try { pc?.dispose() } catch (e: Exception) {}
        pc = null
        try { factory?.dispose() } catch (e: Exception) {}
        factory = null
        ice.reset()
        try { video.clearImage() } catch (e: Exception) {}
        remoteW = 0
        remoteH = 0
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.isSpeakerphoneOn = false
        am.mode = AudioManager.MODE_NORMAL
    }

    // ---------- KONTROL SENTUH (mode "control") ----------
    // Video view diasumsikan memenuhi layar (FIT), jadi posisi sentuh dipetakan
    // proporsional ke resolusi layar HP kedua. Bisa sedikit meleset kalau rasio
    // layar dua HP jauh berbeda.

    private var downX = 0f
    private var downY = 0f
    private var downT = 0L

    private fun sendKey(name: String) {
        if (activeKind == "control" && camStreaming) {
            sig?.send(JSONObject().put("type", "input").put("action", "key").put("name", name))
        }
    }

    private fun setupTouch() {
        video.setOnTouchListener { v, ev ->
            if (activeKind != "control" || !camStreaming || remoteW <= 0 || remoteH <= 0) {
                return@setOnTouchListener false
            }
            val rx = remoteW.toFloat() / v.width.toFloat()
            val ry = remoteH.toFloat() / v.height.toFloat()
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x; downY = ev.y; downT = System.currentTimeMillis()
                }
                MotionEvent.ACTION_UP -> {
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    val dur = (System.currentTimeMillis() - downT).coerceAtLeast(30)
                    val j = JSONObject().put("type", "input")
                    if (abs(dx) < dp(16) && abs(dy) < dp(16)) {
                        j.put("action", "tap").put("x", downX * rx).put("y", downY * ry).put("dur", 60)
                    } else {
                        j.put("action", "swipe")
                            .put("x1", downX * rx).put("y1", downY * ry)
                            .put("x2", ev.x * rx).put("y2", ev.y * ry)
                            .put("dur", dur)
                    }
                    sig?.send(j)
                }
            }
            true
        }
    }

    private fun ago(ts: Long): String {
        if (ts == 0L) return ""
        val m = (System.currentTimeMillis() - ts) / 60000
        return when {
            m < 1 -> "baru saja"
            m < 60 -> "$m mnt lalu"
            else -> "${m / 60} jam lalu"
        }
    }

    private fun render() {
        if (!::tvStatus.isInitialized) return
        val title = StringBuilder(devName)
        if (model.isNotEmpty()) title.append(" • ").append(model)
        if (androidVer.isNotEmpty()) title.append(" • Android ").append(androidVer)

        val kindLabel = when (wantKind) {
            "screen" -> "pantau layar"
            "control" -> "kontrol HP"
            else -> "kamera"
        }
        val line1 = when {
            !sigOn -> "Menyambung ke server…"
            powerOn == false -> "Koneksi diputus • kamera/layar dikunci"
            !camOnline -> "HP kedua offline"
            camStreaming -> "Aktif: $kindLabel${if (wantKind == "cam") " (${if (facing == "front") "depan" else "belakang"})" else ""}"
            connecting -> "Menyalakan $kindLabel…"
            else -> "HP kedua online • belum aktif"
        }
        val line2 = if (level >= 0) {
            "Baterai HP kedua: $level%${if (charging) " • mengisi" else ""} • ${ago(batTs)}"
        } else {
            "Baterai HP kedua: belum ada data"
        }
        tvStatus.text = "$title\n$line1\n$line2"

        val lat = locLat
        val lng = locLng
        tvLoc.text = when {
            locPending -> "Lokasi: mencari…"
            locMsg.isNotEmpty() -> "Lokasi: $locMsg"
            lat != null && lng != null -> {
                val acc = if (locAcc >= 0) " (±${locAcc.toInt()} m)" else ""
                val old = if (locStale) " • terakhir diketahui" else ""
                "Lokasi: ${fmt(lat)}, ${fmt(lng)}$acc • ${ago(locTs)}$old — ketuk untuk buka peta"
            }
            else -> "Lokasi: belum dilacak"
        }

        val ready = sigOn && powerOn == true && camOnline

        fun mark(b: Button, on: Boolean, label: String) {
            b.text = if (on) "• $label" else label
        }
        mark(btnKindCam, wantKind == "cam", "Kamera")
        mark(btnKindScreen, wantKind == "screen", "Pantau layar")
        mark(btnKindControl, wantKind == "control", "Kontrol HP")
        btnKindCam.isEnabled = ready || wantKind == "cam"
        btnKindScreen.isEnabled = ready || wantKind == "screen"
        btnKindControl.isEnabled = ready || wantKind == "control"

        btnPower.isEnabled = sigOn && powerOn != null
        btnPower.text = if (powerOn == false) "Mulai" else "Putuskan"
        btnToggle.isEnabled = ready
        btnToggle.text = if (camStreaming || connecting) "Tutup" else "Buka"
        btnSwitch.isEnabled = ready && wantKind == "cam"
        btnSwitch.visibility = if (wantKind == "cam") View.VISIBLE else View.GONE
        btnMute.text = if (muted) "Nyalakan suara" else "Bisukan"
        btnLocate.isEnabled = sigOn && camOnline

        navBar.visibility = if (activeKind == "control" && camStreaming) View.VISIBLE else View.GONE
    }
}
