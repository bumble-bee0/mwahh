package com.mwahh.app

import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import org.webrtc.*
import org.webrtc.audio.JavaAudioDeviceModule

// Berjalan di HP utama: tampilan seperti kamera biasa + tombol kontrol.
class MonitorActivity : AppCompatActivity() {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var video: SurfaceViewRenderer
    private lateinit var tvStatus: TextView
    private lateinit var btnToggle: Button
    private lateinit var btnSwitch: Button
    private lateinit var btnMute: Button

    private var sig: Signaling? = null
    private var egl: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private val ice = IceQueue()
    private var remoteVideo: VideoTrack? = null
    private var remoteAudio: AudioTrack? = null

    private var sigOn = false
    private var camOnline = false
    private var camStreaming = false
    private var connecting = false
    private var facing = "back"
    private var level = -1
    private var charging = false
    private var batTs = 0L
    private var muted = false

    private val ticker = object : Runnable {
        override fun run() {
            render()
            main.postDelayed(this, 30000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        volumeControlStream = AudioManager.STREAM_VOICE_CALL

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF000000.toInt())

        video = SurfaceViewRenderer(this)
        root.addView(video, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        tvStatus = TextView(this)
        tvStatus.setTextColor(0xFFFFFFFF.toInt())
        tvStatus.setBackgroundColor(0x99000000.toInt())
        tvStatus.setPadding(dp(14), dp(12), dp(14), dp(12))
        tvStatus.textSize = 14f
        val topLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        topLp.gravity = Gravity.TOP
        root.addView(tvStatus, topLp)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(0x99000000.toInt())
        bar.setPadding(dp(8), dp(8), dp(8), dp(8))
        btnToggle = Button(this)
        btnSwitch = Button(this)
        btnMute = Button(this)
        btnSwitch.text = "Ganti kamera"
        for (b in listOf(btnToggle, btnSwitch, btnMute)) {
            b.isAllCaps = false
            bar.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val botLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        botLp.gravity = Gravity.BOTTOM
        root.addView(bar, botLp)
        setContentView(root)

        btnToggle.setOnClickListener {
            if (!sigOn || !camOnline) {
                Toast.makeText(this, "HP kedua sedang offline", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (camStreaming || connecting) {
                sig?.send(Rtc.cmd("stop"))
                teardownPc()
                camStreaming = false
                connecting = false
            } else {
                connecting = true
                sig?.send(Rtc.cmd("start"))
            }
            render()
        }
        btnSwitch.setOnClickListener {
            if (sigOn && camOnline) sig?.send(Rtc.cmd("switch"))
        }
        btnMute.setOnClickListener {
            muted = !muted
            remoteAudio?.setEnabled(!muted)
            render()
        }
        render()
    }

    override fun onStart() {
        super.onStart()
        val e = EglBase.create()
        egl = e
        video.init(e.eglBaseContext, null)
        video.setEnableHardwareScaler(true)
        sig = Signaling(this, "monitor", { onMsg(it) }, { online ->
            sigOn = online
            if (!online) {
                camOnline = false
                camStreaming = false
                connecting = false
                teardownPc()
            }
            render()
        })
        sig?.start()
        main.post(ticker)
    }

    override fun onStop() {
        main.removeCallbacks(ticker)
        if (camStreaming || connecting) sig?.send(Rtc.cmd("stop"))
        sig?.stop()
        sig = null
        teardownPc()
        camStreaming = false
        connecting = false
        sigOn = false
        camOnline = false
        video.release()
        egl?.release()
        egl = null
        super.onStop()
    }

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "peer" -> {
                camOnline = j.optBoolean("online")
                if (!camOnline) {
                    camStreaming = false
                    connecting = false
                    teardownPc()
                }
            }
            "battery" -> {
                level = j.optInt("level", -1)
                charging = j.optBoolean("charging")
                batTs = j.optLong("ts", System.currentTimeMillis())
            }
            "state" -> {
                camStreaming = j.optBoolean("streaming")
                facing = j.optString("facing", facing)
                if (!camStreaming) {
                    connecting = false
                    teardownPc()
                }
            }
            "offer" -> handleOffer(j.getString("sdp"))
            "ice" -> {
                try { ice.add(pc, Rtc.jsonToIce(j)) } catch (e: Exception) {}
            }
        }
        render()
    }

    private fun handleOffer(sdp: String) {
        teardownPc()
        Thread {
            val servers = Rtc.fetchIce(this)
            main.post {
                if (sig == null) return@post
                try {
                    answer(servers, sdp)
                } catch (e: Exception) {
                    Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun answer(servers: List<PeerConnection.IceServer>, sdp: String) {
        val eglB = egl ?: return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .createInitializationOptions()
        )
        val adm = JavaAudioDeviceModule.builder(this).createAudioDeviceModule()
        val f = PeerConnectionFactory.builder()
            .setAudioDeviceModule(adm)
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglB.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglB.eglBaseContext))
            .createPeerConnectionFactory()
        adm.release()
        factory = f

        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = true

        val cfg = PeerConnection.RTCConfiguration(servers)
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val p = f.createPeerConnection(cfg, object : Rtc.PcObserver() {
            override fun onIceCandidate(c: IceCandidate?) {
                if (c != null) main.post { sig?.send(Rtc.iceToJson(c)) }
            }

            override fun onTrack(transceiver: RtpTransceiver?) {
                val tr = transceiver?.receiver?.track() ?: return
                main.post {
                    when (tr) {
                        is VideoTrack -> {
                            remoteVideo = tr
                            tr.addSink(video)
                        }
                        is AudioTrack -> {
                            remoteAudio = tr
                            tr.setEnabled(!muted)
                        }
                    }
                }
            }

            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                if (s == PeerConnection.IceConnectionState.FAILED) {
                    main.post {
                        sig?.send(Rtc.cmd("stop"))
                        teardownPc()
                        camStreaming = false
                        connecting = false
                        render()
                        Toast.makeText(
                            this@MonitorActivity,
                            "Video gagal tersambung (jaringan mungkin butuh TURN)",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }) ?: throw IllegalStateException("peer connection gagal dibuat")
        pc = p
        ice.reset()

        p.setRemoteDescription(object : Rtc.Sdp() {
            override fun onSetSuccess() {
                main.post {
                    if (pc !== p) return@post
                    ice.flush(p)
                    p.createAnswer(object : Rtc.Sdp() {
                        override fun onCreateSuccess(d: SessionDescription?) {
                            if (d == null) return
                            p.setLocalDescription(Rtc.Sdp(), d)
                            main.post {
                                sig?.send(JSONObject().put("type", "answer").put("sdp", d.description))
                            }
                        }
                    }, MediaConstraints())
                }
            }
        }, SessionDescription(SessionDescription.Type.OFFER, sdp))
    }

    private fun teardownPc() {
        try { remoteVideo?.removeSink(video) } catch (e: Exception) {}
        remoteVideo = null
        remoteAudio = null
        try { pc?.close() } catch (e: Exception) {}
        try { pc?.dispose() } catch (e: Exception) {}
        pc = null
        try { factory?.dispose() } catch (e: Exception) {}
        factory = null
        ice.reset()
        try { video.clearImage() } catch (e: Exception) {}
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.isSpeakerphoneOn = false
        am.mode = AudioManager.MODE_NORMAL
    }

    private fun ago(ts: Long): String {
        if (ts == 0L) return ""
        val m = (System.currentTimeMillis() - ts) / 60000
        return when {
            m < 1 -> "baru saja"
            m < 60 -> "$m mnt lalu"
            else -> "${m / 60} jam lalu"
        }
    }

    private fun render() {
        val line1 = when {
            !sigOn -> "Menyambung ke server…"
            !camOnline -> "HP kedua offline"
            camStreaming -> "Kamera menyala (${if (facing == "front") "depan" else "belakang"})"
            connecting -> "Menyalakan kamera…"
            else -> "HP kedua online • kamera mati"
        }
        val line2 = if (level >= 0) {
            "Baterai HP kedua: $level%${if (charging) " • mengisi" else ""} • ${ago(batTs)}"
        } else {
            "Baterai HP kedua: belum ada data"
        }
        tvStatus.text = "$line1\n$line2"
        btnToggle.text = if (camStreaming || connecting) "Tutup kamera" else "Buka kamera"
        btnMute.text = if (muted) "Nyalakan suara" else "Bisukan"
    }
}
