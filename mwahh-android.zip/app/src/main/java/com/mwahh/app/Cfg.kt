package com.mwahh.app

import android.content.Context
import java.net.URLEncoder
import java.security.SecureRandom

object Cfg {
    const val HOST = "mwahh.mwahh.workers.dev"

    private fun prefs(c: Context) = c.getSharedPreferences("mwahh", Context.MODE_PRIVATE)

    fun code(c: Context): String = prefs(c).getString("code", "") ?: ""
    fun key(c: Context): String = prefs(c).getString("key", "") ?: ""
    fun configured(c: Context) = code(c).isNotEmpty() && key(c).isNotEmpty()

    fun save(c: Context, code: String, key: String) {
        prefs(c).edit().putString("code", code).putString("key", key).apply()
    }

    fun randomCode(): String {
        val chars = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = SecureRandom()
        val sb = StringBuilder()
        repeat(16) { sb.append(chars[r.nextInt(chars.length)]) }
        return sb.toString()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun wsUrl(c: Context) =
        "wss://$HOST/ws?code=${enc(code(c))}&role=monitor&key=${enc(key(c))}"

    fun turnUrl(c: Context) = "https://$HOST/turn?key=${enc(key(c))}"
}
