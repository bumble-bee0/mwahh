package com.mwahh.app

import android.content.Context
import java.net.URLEncoder
import java.security.SecureRandom

object Cfg {
    const val HOST = "mwahh.mwahh.workers.dev"

    private fun prefs(c: Context) = c.getSharedPreferences("mwahh", Context.MODE_PRIVATE)

    fun key(c: Context): String = prefs(c).getString("key", "") ?: ""
    fun setKey(c: Context, k: String) {
        prefs(c).edit().putString("key", k).apply()
    }

    // Kualitas video: "low" (hemat kuota/baterai), "mid" (normal), "high" (HD tinggi).
    fun quality(c: Context): String = prefs(c).getString("quality", "mid") ?: "mid"
    fun setQuality(c: Context, q: String) {
        prefs(c).edit().putString("quality", q).apply()
    }

    fun randomCode(): String {
        val chars = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = SecureRandom()
        val sb = StringBuilder()
        repeat(16) { sb.append(chars[r.nextInt(chars.length)]) }
        return sb.toString()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun wsUrl(c: Context, code: String) =
        "wss://$HOST/ws?code=${enc(code)}&role=monitor&key=${enc(key(c))}"

    fun turnUrl(c: Context) = "https://$HOST/turn?key=${enc(key(c))}"
    fun statusUrl(c: Context, code: String) = "https://$HOST/status?code=${enc(code)}&key=${enc(key(c))}"
    fun registerUrl(c: Context, code: String) = "https://$HOST/register?code=${enc(code)}&key=${enc(key(c))}"
    fun forgetUrl(c: Context, code: String) = "https://$HOST/forget?code=${enc(code)}&key=${enc(key(c))}"
}
