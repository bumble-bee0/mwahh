package com.mwahh.app

import android.content.Context
import java.net.URLEncoder

object Cfg {
    const val HOST = "mwahh.mwahh.workers.dev"

    private fun prefs(c: Context) = c.getSharedPreferences("mwahh", Context.MODE_PRIVATE)

    fun code(c: Context): String = prefs(c).getString("code", "") ?: ""
    fun key(c: Context): String = prefs(c).getString("key", "") ?: ""

    fun save(c: Context, code: String, key: String) {
        prefs(c).edit().putString("code", code).putString("key", key).apply()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun wsUrl(c: Context, role: String) =
        "wss://$HOST/ws?code=${enc(code(c))}&role=$role&key=${enc(key(c))}"

    fun turnUrl(c: Context) = "https://$HOST/turn?key=${enc(key(c))}"
}
