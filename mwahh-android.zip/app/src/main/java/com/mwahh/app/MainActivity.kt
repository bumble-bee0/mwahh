package com.mwahh.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var etCode: EditText
    private lateinit var etKey: EditText
    private lateinit var tvInfo: TextView

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            if (r[Manifest.permission.CAMERA] == true && r[Manifest.permission.RECORD_AUDIO] == true) {
                startCam()
            } else {
                tvInfo.text = "Izin kamera dan mikrofon harus diizinkan."
            }
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(48), dp(24), dp(24))

        val title = TextView(this)
        title.text = "mwahh"
        title.textSize = 28f
        box.addView(title)

        etCode = EditText(this)
        etCode.hint = "Kode (huruf/angka, 8-32 karakter)"
        etCode.setText(Cfg.code(this))
        etCode.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        box.addView(etCode)

        etKey = EditText(this)
        etKey.hint = "Kunci aplikasi"
        etKey.setText(Cfg.key(this))
        etKey.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        box.addView(etKey)

        val btnCam = Button(this)
        btnCam.text = "Jadikan HP Kamera"
        btnCam.isAllCaps = false
        box.addView(btnCam)

        val btnMon = Button(this)
        btnMon.text = "Jadikan HP Monitor"
        btnMon.isAllCaps = false
        box.addView(btnMon)

        val btnStop = Button(this)
        btnStop.text = "Hentikan kamera"
        btnStop.isAllCaps = false
        box.addView(btnStop)

        tvInfo = TextView(this)
        tvInfo.setPadding(0, dp(16), 0, 0)
        box.addView(tvInfo)

        val sv = ScrollView(this)
        sv.addView(box, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(sv)

        btnCam.setOnClickListener {
            if (!readInput()) return@setOnClickListener
            val need = arrayListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
            permLauncher.launch(need.toTypedArray())
        }
        btnMon.setOnClickListener {
            if (!readInput()) return@setOnClickListener
            startActivity(Intent(this, MonitorActivity::class.java))
        }
        btnStop.setOnClickListener {
            stopService(Intent(this, CameraService::class.java))
            tvInfo.text = "Kamera dihentikan."
        }
    }

    private fun readInput(): Boolean {
        val code = etCode.text.toString().trim()
        val key = etKey.text.toString().trim()
        if (!Regex("^[A-Za-z0-9]{8,32}$").matches(code)) {
            tvInfo.text = "Kode harus 8-32 karakter, hanya huruf dan angka."
            return false
        }
        if (key.isEmpty()) {
            tvInfo.text = "Kunci aplikasi belum diisi."
            return false
        }
        Cfg.save(this, code, key)
        return true
    }

    private fun startCam() {
        ContextCompat.startForegroundService(this, Intent(this, CameraService::class.java))
        tvInfo.text = "Layanan kamera dijalankan. Tekan tombol Home (jangan geser aplikasi dari recent), lalu simpan HP."
    }
}
