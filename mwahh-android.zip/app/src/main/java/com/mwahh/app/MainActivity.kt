package com.mwahh.app

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

// Pengaturan: kode sistem + kunci aplikasi. Kalau sudah terisi, langsung masuk ke monitor.
class MainActivity : AppCompatActivity() {

    private lateinit var etCode: EditText
    private lateinit var etKey: EditText
    private lateinit var tvInfo: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val edit = intent.getBooleanExtra("edit", false)
        if (!edit && Cfg.configured(this)) {
            startActivity(Intent(this, MonitorActivity::class.java))
            finish()
            return
        }

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(48), dp(24), dp(24))

        val title = TextView(this)
        title.text = "mwahh"
        title.textSize = 28f
        box.addView(title)

        etCode = EditText(this)
        etCode.hint = "Kode sistem (16 karakter disarankan)"
        etCode.setText(Cfg.code(this))
        etCode.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        box.addView(etCode)

        val btnRandom = Button(this)
        btnRandom.text = "Buat kode acak"
        btnRandom.isAllCaps = false
        box.addView(btnRandom)

        etKey = EditText(this)
        etKey.hint = "Kunci aplikasi"
        etKey.setText(Cfg.key(this))
        etKey.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        box.addView(etKey)

        val btnSave = Button(this)
        btnSave.text = "Simpan & buka monitor"
        btnSave.isAllCaps = false
        box.addView(btnSave)

        tvInfo = TextView(this)
        tvInfo.setPadding(0, dp(16), 0, 0)
        tvInfo.text = "Kode ini yang nanti dimasukkan di HP kedua (aplikasi Sistem Keamanan)."
        box.addView(tvInfo)

        val sv = ScrollView(this)
        sv.addView(box, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(sv)

        btnRandom.setOnClickListener {
            etCode.setText(Cfg.randomCode())
        }
        btnSave.setOnClickListener {
            val code = etCode.text.toString().trim()
            val key = etKey.text.toString().trim()
            if (!Regex("^[A-Za-z0-9]{8,32}$").matches(code)) {
                tvInfo.text = "Kode harus 8-32 karakter, hanya huruf dan angka."
                return@setOnClickListener
            }
            if (key.isEmpty()) {
                tvInfo.text = "Kunci aplikasi belum diisi."
                return@setOnClickListener
            }
            Cfg.save(this, code, key)
            startActivity(Intent(this, MonitorActivity::class.java))
            finish()
        }
    }
}
