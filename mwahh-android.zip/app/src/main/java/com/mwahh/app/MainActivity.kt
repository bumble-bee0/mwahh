package com.mwahh.app

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

// Daftar perangkat, seperti daftar WiFi: ketuk salah satu untuk melihat kameranya.
class MainActivity : AppCompatActivity() {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var listBox: LinearLayout
    private lateinit var tvHint: TextView
    private val status = HashMap<String, JSONObject?>()

    private val refresher = object : Runnable {
        override fun run() {
            refreshStatus()
            main.postDelayed(this, 20000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(40), dp(20), dp(20))

        val title = TextView(this)
        title.text = "mwahh"
        title.textSize = 28f
        box.addView(title)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val btnAdd = Button(this)
        btnAdd.text = "Tambah perangkat"
        btnAdd.isAllCaps = false
        val btnKey = Button(this)
        btnKey.text = "Kunci"
        btnKey.isAllCaps = false
        bar.addView(btnAdd, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f))
        bar.addView(btnKey, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(bar)

        tvHint = TextView(this)
        tvHint.setPadding(0, dp(12), 0, dp(8))
        box.addView(tvHint)

        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        box.addView(listBox)

        val sv = ScrollView(this)
        sv.addView(box, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(sv)

        btnAdd.setOnClickListener { addDialog() }
        btnKey.setOnClickListener { keyDialog() }
    }

    override fun onResume() {
        super.onResume()
        if (Cfg.key(this).isEmpty()) keyDialog()
        render()
        main.post(refresher)
    }

    override fun onPause() {
        main.removeCallbacks(refresher)
        super.onPause()
    }

    private fun keyDialog() {
        val et = EditText(this)
        et.hint = "Kunci aplikasi"
        et.setText(Cfg.key(this))
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        val b = AlertDialog.Builder(this)
            .setTitle("Kunci aplikasi")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                Cfg.setKey(this, et.text.toString().trim())
                status.clear()
                render()
                refreshStatus()
            }
        if (Cfg.key(this).isNotEmpty()) b.setNegativeButton("Batal", null)
        b.setCancelable(Cfg.key(this).isNotEmpty())
        b.show()
    }

    private fun addDialog() {
        if (Cfg.key(this).isEmpty()) {
            keyDialog()
            return
        }
        val form = LinearLayout(this)
        form.orientation = LinearLayout.VERTICAL
        form.setPadding(dp(20), dp(8), dp(20), 0)
        val etName = EditText(this)
        etName.hint = "Nama perangkat (misal: Teras)"
        form.addView(etName)
        val etCode = EditText(this)
        etCode.hint = "Kode (8-32 huruf/angka)"
        etCode.setText(Cfg.randomCode())
        etCode.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        form.addView(etCode)
        val note = TextView(this)
        note.text = "Masukkan kode ini di aplikasi Sistem Keamanan pada HP kedua."
        note.textSize = 12f
        form.addView(note)

        AlertDialog.Builder(this)
            .setTitle("Tambah perangkat")
            .setView(form)
            .setPositiveButton("Simpan") { _, _ ->
                val code = etCode.text.toString().trim()
                if (!Regex("^[A-Za-z0-9]{8,32}$").matches(code)) {
                    Toast.makeText(this, "Kode harus 8-32 huruf/angka", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                if (Devices.list(this).any { it.code == code }) {
                    Toast.makeText(this, "Kode itu sudah ada", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val name = etName.text.toString().trim()
                    .ifEmpty { "HP ${Devices.list(this).size + 1}" }
                Devices.add(this, Device(name, code))
                // Daftarkan ke server supaya HP kedua langsung bisa tersambung.
                Thread { Api.get(Cfg.registerUrl(this, code)) }.start()
                render()
                refreshStatus()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deleteDialog(d: Device) {
        AlertDialog.Builder(this)
            .setTitle("Hapus ${d.name}?")
            .setMessage("Perangkat dihapus dari daftar dan dari server. Aplikasi di HP kedua sebaiknya dicopot.")
            .setPositiveButton("Hapus") { _, _ ->
                Thread { Api.get(Cfg.forgetUrl(this, d.code)) }.start()
                Devices.remove(this, d.code)
                status.remove(d.code)
                render()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun refreshStatus() {
        if (Cfg.key(this).isEmpty()) return
        for (d in Devices.list(this)) {
            Thread {
                val s = Api.get(Cfg.statusUrl(this, d.code))
                main.post {
                    status[d.code] = s
                    render()
                }
            }.start()
        }
    }

    private fun subtitle(s: JSONObject?): String {
        if (s == null) return "memeriksa…"
        val parts = ArrayList<String>()
        val model = s.optJSONObject("info")?.optString("model") ?: ""
        if (model.isNotEmpty()) parts.add(model)
        parts.add(
            when {
                !s.optBoolean("reg") -> "belum terdaftar"
                !s.optBoolean("on", true) -> "diputus"
                s.optBoolean("online") -> "online"
                else -> "offline"
            }
        )
        val bat = s.optJSONObject("battery")?.optInt("level", -1) ?: -1
        if (bat >= 0) parts.add("baterai $bat%")
        return parts.joinToString(" • ")
    }

    private fun render() {
        val devices = Devices.list(this)
        tvHint.text = if (devices.isEmpty())
            "Belum ada perangkat. Tekan Tambah perangkat." else "Ketuk perangkat untuk membuka kameranya. Tekan lama untuk menghapus."
        listBox.removeAllViews()
        for (d in devices) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setBackgroundColor(0xFFEFEFEF.toInt())
            row.setPadding(dp(16), dp(14), dp(16), dp(14))
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(10)

            val t1 = TextView(this)
            t1.text = d.name
            t1.textSize = 18f
            t1.setTypeface(null, Typeface.BOLD)
            row.addView(t1)

            val t2 = TextView(this)
            t2.text = subtitle(status[d.code])
            t2.textSize = 13f
            t2.setTextColor(0xFF555555.toInt())
            row.addView(t2)

            row.setOnClickListener {
                startActivity(
                    Intent(this, MonitorActivity::class.java)
                        .putExtra("code", d.code)
                        .putExtra("name", d.name)
                )
            }
            row.setOnLongClickListener {
                deleteDialog(d)
                true
            }
            listBox.addView(row, lp)
        }
    }
}
