package com.mwahh.app

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

// Daftar perangkat (HP kedua). Ketuk salah satu untuk membuka menunya.
class MainActivity : AppCompatActivity() {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var listBox: LinearLayout
    private lateinit var tvHint: TextView
    private val status = HashMap<String, JSONObject?>()
    private val healing: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())

    private val refresher = object : Runnable {
        override fun run() {
            refreshStatus()
            main.postDelayed(this, 20000)
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(44), dp(18), dp(24))

        box.addView(Ui.text(this, "mwahh", 30f, Ui.TEXT, true))
        val sub = Ui.text(this, "Pantau HP kedua dari mana saja", 14f, Ui.SUB)
        sub.setPadding(0, dp(2), 0, dp(16))
        box.addView(sub)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val btnAdd = Ui.button(this, "+ Tambah perangkat", true)
        val btnKey = Ui.button(this, "Kunci", false)
        val lpAdd = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f)
        lpAdd.rightMargin = dp(10)
        bar.addView(btnAdd, lpAdd)
        bar.addView(btnKey, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(bar)

        tvHint = Ui.text(this, "", 13f, Ui.SUB)
        tvHint.setPadding(dp(2), dp(16), 0, dp(10))
        box.addView(tvHint)

        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        box.addView(listBox)

        val sv = ScrollView(this)
        sv.addView(box, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(sv)

        btnAdd.setOnClickListener { addDialog() }
        btnKey.setOnClickListener { keyDialog() }
    }

    override fun onResume() {
        super.onResume()
        if (Cfg.key(this).isEmpty()) keyDialog()
        render()
        main.post(refresher)
    }

    override fun onPause() {
        main.removeCallbacks(refresher)
        super.onPause()
    }

    private fun keyDialog() {
        val et = EditText(this)
        et.hint = "Kunci aplikasi"
        et.setText(Cfg.key(this))
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        val b = AlertDialog.Builder(this)
            .setTitle("Kunci aplikasi")
            .setMessage("Kunci ini harus sama dengan APP_KEY di server.")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                Cfg.setKey(this, et.text.toString().trim())
                status.clear()
                render()
                refreshStatus()
            }
        if (Cfg.key(this).isNotEmpty()) b.setNegativeButton("Batal", null)
        b.setCancelable(Cfg.key(this).isNotEmpty())
        b.show()
    }

    private fun addDialog() {
        if (Cfg.key(this).isEmpty()) {
            keyDialog()
            return
        }
        val form = LinearLayout(this)
        form.orientation = LinearLayout.VERTICAL
        form.setPadding(dp(20), dp(8), dp(20), 0)
        val etName = EditText(this)
        etName.hint = "Nama perangkat (misal: Teras)"
        form.addView(etName)
        val etCode = EditText(this)
        etCode.hint = "Kode (8-32 huruf/angka)"
        etCode.setText(Cfg.randomCode())
        // VISIBLE_PASSWORD mematikan koreksi otomatis dan huruf kapital otomatis di keyboard.
        etCode.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        form.addView(etCode)
        val note = Ui.text(this, "Masukkan kode ini di aplikasi Sistem Keamanan pada HP kedua. Huruf besar/kecil tidak dibedakan.", 12f, Ui.SUB)
        note.setPadding(0, dp(6), 0, 0)
        form.addView(note)
        val tvErr = Ui.text(this, "", 13f, Ui.BAD)
        tvErr.setPadding(0, dp(8), 0, 0)
        form.addView(tvErr)

        val dlg = AlertDialog.Builder(this)
            .setTitle("Tambah perangkat")
            .setView(form)
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)
            .create()
        dlg.setOnShowListener {
            val ok = dlg.getButton(DialogInterface.BUTTON_POSITIVE)
            ok.setOnClickListener {
                val code = etCode.text.toString().trim()
                if (!Regex("^[A-Za-z0-9]{8,32}$").matches(code)) {
                    tvErr.setTextColor(Ui.BAD)
                    tvErr.text = "Kode harus 8-32 huruf/angka, tanpa spasi atau simbol."
                    return@setOnClickListener
                }
                if (Devices.list(this).any { it.code.equals(code, ignoreCase = true) }) {
                    tvErr.setTextColor(Ui.BAD)
                    tvErr.text = "Kode itu sudah ada di daftar."
                    return@setOnClickListener
                }
                val name = etName.text.toString().trim()
                    .ifEmpty { "HP ${Devices.list(this).size + 1}" }
                ok.isEnabled = false
                tvErr.setTextColor(Ui.SUB)
                tvErr.text = "Mendaftarkan ke server…"
                // Perangkat baru disimpan HANYA kalau server benar-benar menerima kodenya.
                Thread {
                    val r = Api.request(Cfg.registerUrl(this, code))
                    main.post {
                        if (r.code == 200 && r.json?.optBoolean("ok") == true) {
                            Devices.add(this, Device(name, code))
                            render()
                            refreshStatus()
                            dlg.dismiss()
                        } else {
                            ok.isEnabled = true
                            tvErr.setTextColor(Ui.BAD)
                            tvErr.text = when (r.code) {
                                403 -> "Kunci aplikasi salah. Periksa lewat tombol Kunci."
                                400 -> "Server menolak kode ini. Coba kode lain."
                                -1 -> "Tidak bisa menghubungi server. Cek internet."
                                else -> "Gagal mendaftar (kode ${r.code})."
                            }
                        }
                    }
                }.start()
            }
        }
        dlg.show()
    }

    private fun deleteDialog(d: Device) {
        AlertDialog.Builder(this)
            .setTitle("Hapus ${d.name}?")
            .setMessage("Perangkat dihapus dari daftar dan dari server. Aplikasi di HP kedua sebaiknya dicopot.")
            .setPositiveButton("Hapus") { _, _ ->
                Thread { Api.get(Cfg.forgetUrl(this, d.code)) }.start()
                Devices.remove(this, d.code)
                status.remove(d.code)
                render()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun refreshStatus() {
        if (Cfg.key(this).isEmpty()) return
        for (d in Devices.list(this)) {
            Thread {
                val s = Api.get(Cfg.statusUrl(this, d.code))
                // Kalau server tidak mengenali kode ini (misal data server terhapus), daftarkan ulang diam-diam.
                if (s != null && !s.optBoolean("reg") && healing.add(d.code)) {
                    Api.get(Cfg.registerUrl(this, d.code))
                }
                main.post {
                    status[d.code] = s
                    render()
                }
            }.start()
        }
    }

    // Pasangan (teks status, warna titik) untuk satu perangkat.
    private fun statusOf(s: JSONObject?): Pair<String, Int> {
        if (s == null) return Pair("memeriksa…", Ui.GRAY)
        return when {
            !s.optBoolean("reg") -> Pair("mendaftarkan…", Ui.WARN)
            !s.optBoolean("on", true) -> Pair("diputus", Ui.WARN)
            s.optBoolean("online") -> Pair("online", Ui.GOOD)
            !s.optBoolean("claimed") -> Pair("menunggu HP kedua dipasang", Ui.WARN)
            else -> Pair("offline", Ui.BAD)
        }
    }

    private fun detail(s: JSONObject?): String {
        if (s == null) return ""
        val parts = ArrayList<String>()
        val model = s.optJSONObject("info")?.optString("model") ?: ""
        if (model.isNotEmpty()) parts.add(model)
        val b = s.optJSONObject("battery")
        val bat = b?.optInt("level", -1) ?: -1
        if (b != null && bat >= 0) {
            val age = Ui.ago(b.optLong("ts", 0L))
            parts.add("baterai $bat%" + (if (age.isNotEmpty()) " ($age)" else ""))
        }
        return parts.joinToString(" • ")
    }

    private fun render() {
        val devices = Devices.list(this)
        tvHint.text = if (devices.isEmpty())
            "Belum ada perangkat. Tekan Tambah perangkat." else "Ketuk perangkat untuk membuka menunya. Tekan lama untuk menghapus."
        listBox.removeAllViews()
        for (d in devices) {
            val s = status[d.code]
            val (label, color) = statusOf(s)

            val card = Ui.card(this)
            val top = LinearLayout(this)
            top.orientation = LinearLayout.HORIZONTAL
            top.gravity = Gravity.CENTER_VERTICAL
            val dotLp = LinearLayout.LayoutParams(dp(10), dp(10))
            dotLp.rightMargin = dp(10)
            top.addView(Ui.dot(this, color), dotLp)
            top.addView(Ui.text(this, d.name, 18f, Ui.TEXT, true))
            card.addView(top)

            val st = Ui.text(this, label, 13f, color, true)
            st.setPadding(dp(20), dp(2), 0, 0)
            card.addView(st)
            val det = detail(s)
            if (det.isNotEmpty()) {
                val t = Ui.text(this, det, 13f, Ui.SUB)
                t.setPadding(dp(20), dp(2), 0, 0)
                card.addView(t)
            }

            card.setOnClickListener {
                startActivity(
                    Intent(this, DeviceMenuActivity::class.java)
                        .putExtra("code", d.code)
                        .putExtra("name", d.name)
                )
            }
            card.setOnLongClickListener {
                deleteDialog(d)
                true
            }
            listBox.addView(card, Ui.lpMatch(this, 10))
        }
    }
}
