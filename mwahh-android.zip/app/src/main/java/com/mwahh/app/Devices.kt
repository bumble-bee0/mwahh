package com.mwahh.app

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Device(val name: String, val code: String)

// Daftar perangkat (HP kedua) yang disimpan di HP utama.
object Devices {
    private fun prefs(c: Context) = c.getSharedPreferences("mwahh", Context.MODE_PRIVATE)

    fun list(c: Context): List<Device> {
        val p = prefs(c)
        val raw = p.getString("devices", null)
        if (raw == null) {
            // Pindahan dari versi lama (satu kode saja).
            val old = p.getString("code", "") ?: ""
            if (old.isNotEmpty()) {
                save(c, listOf(Device("HP 1", old)))
                return list(c)
            }
            return emptyList()
        }
        val out = ArrayList<Device>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Device(o.getString("name"), o.getString("code")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun add(c: Context, d: Device) = save(c, list(c) + d)

    fun remove(c: Context, code: String) = save(c, list(c).filter { it.code != code })

    private fun save(c: Context, l: List<Device>) {
        val arr = JSONArray()
        for (d in l) arr.put(JSONObject().put("name", d.name).put("code", d.code))
        prefs(c).edit().putString("devices", arr.toString()).apply()
    }
}

data class ApiResult(val code: Int, val json: JSONObject?)

object Api {
    private val client = OkHttpClient.Builder().callTimeout(10, TimeUnit.SECONDS).build()

    // Seperti get(), tapi mengembalikan kode HTTP (-1 kalau tidak bisa terhubung) supaya
    // penyebab gagal bisa ditampilkan ke pengguna. Panggil dari thread background.
    fun request(url: String): ApiResult {
        return try {
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                val body = r.body?.string() ?: ""
                val j = try { JSONObject(body) } catch (e: Exception) { null }
                ApiResult(r.code, j)
            }
        } catch (e: Exception) {
            ApiResult(-1, null)
        }
    }

    // Panggil dari thread background. Hasil null kalau gagal.
    fun get(url: String): JSONObject? {
        return try {
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) null else JSONObject(r.body!!.string())
            }
        } catch (e: Exception) {
            null
        }
    }
}
