package com.mwahh.app

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

// Pembantu tampilan supaya semua layar punya gaya yang sama (kartu putih, sudut membulat).
object Ui {
    val BG = 0xFFF4F5F7.toInt()
    val CARD = 0xFFFFFFFF.toInt()
    val TEXT = 0xFF111827.toInt()
    val SUB = 0xFF6B7280.toInt()
    val ACCENT = 0xFF2563EB.toInt()
    val GOOD = 0xFF16A34A.toInt()
    val BAD = 0xFFDC2626.toInt()
    val WARN = 0xFFD97706.toInt()
    val GRAY = 0xFF9CA3AF.toInt()
    val CHIP_OFF = 0xFFE5E7EB.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(c: Context, color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(c, radiusDp).toFloat()
        return g
    }

    fun dot(c: Context, color: Int): View {
        val v = View(c)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        v.background = g
        return v
    }

    fun text(c: Context, s: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    // Kartu putih berisi susunan vertikal.
    fun card(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        l.background = rounded(c, CARD, 14)
        l.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
        l.elevation = dp(c, 1).toFloat()
        return l
    }

    // Tombol dari TextView supaya gayanya seragam. filled=true: biru penuh.
    fun button(c: Context, label: String, filled: Boolean): TextView {
        val t = TextView(c)
        t.text = label
        t.textSize = 14f
        t.gravity = Gravity.CENTER
        t.setTypeface(null, Typeface.BOLD)
        t.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
        t.setTextColor(if (filled) 0xFFFFFFFF.toInt() else ACCENT)
        t.background = rounded(c, if (filled) ACCENT else 0xFFE0E7FF.toInt(), 12)
        t.isClickable = true
        t.isFocusable = true
        return t
    }

    fun lpMatch(c: Context, bottomDp: Int = 0): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(c, bottomDp)
        return lp
    }

    fun ago(ts: Long): String {
        if (ts <= 0L) return ""
        val m = (System.currentTimeMillis() - ts) / 60000
        return when {
            m < 1 -> "baru saja"
            m < 60 -> "$m mnt lalu"
            m < 60 * 24 -> "${m / 60} jam lalu"
            else -> "${m / (60 * 24)} hari lalu"
        }
    }
}
