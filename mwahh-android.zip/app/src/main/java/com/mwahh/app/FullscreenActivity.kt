package com.mwahh.app

import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.*
import org.webrtc.audio.JavaAudioDeviceModule
import java.util.concurrent.TimeUnit
import kotlin.math.abs

// Video benar-benar memenuhi layar, tanpa tombol apapun di atasnya -- kecuali mode
// "control" yang memang BUTUH Home/Back/Recents sebagai kontrol, bukan hiasan.
// Terhubung otomatis begitu dibuka, dan langsung menyalakan kamera/layar sesuai "kind".
class FullscreenActivity : AppCompatActivity() {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var video: SurfaceViewRenderer
    private lateinit var tvMsg: TextView
    private lateinit var navBar: LinearLayout

    private var code = ""
    private var kind = "cam"

    private var sig: Signaling? = null
    private var egl: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private val ice = IceQueue()
    private var lastIce: JSONArray? = null
    private var remoteVideo: VideoTrack? = null
    private var remoteAudio: AudioTrack? = null

    private var sigOn = false
    private var powerOn: Boolean? = null
    private var camOnline = false
    private var camStreaming = false
    private var connecting = false
    private var remoteW = 0
    private var remoteH = 0
    private var startSent = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        code = intent.getStringExtra("code") ?: ""
        kind = intent.getStringExtra("kind") ?: "cam"
        if (code.isEmpty()) {
            finish()
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        volumeControlStream = AudioManager.STREAM_VOICE_CALL
        hideSystemBars()

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF000000.toInt())

        video = SurfaceViewRenderer(this)
        root.addView(video, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        tvMsg = TextView(this)
        tvMsg.setTextColor(0xFFFFFFFF.toInt())
        tvMsg.textSize = 15f
        tvMsg.gravity = Gravity.CENTER
        val msgLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        msgLp.gravity = Gravity.CENTER
        root.addView(tvMsg, msgLp)

        if (kind == "control") {
            navBar = LinearLayout(this)
            navBar.orientation = LinearLayout.HORIZONTAL
            navBar.setBackgroundColor(0x66000000.toInt())
            navBar.setPadding(dp(4), dp(4), dp(4), dp(4))
            val btnHome = Button(this)
            val btnBack = Button(this)
            val btnRecents = Button(this)
            val btnExit = Button(this)
            btnHome.text = "Home"
            btnBack.text = "Back"
            btnRecents.text = "Recents"
            btnExit.text = "✕"
            for (b in listOf(btnHome, btnBack, btnRecents)) {
                b.isAllCaps = false
                b.textSize = 11f
                navBar.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            btnExit.isAllCaps = false
            btnExit.textSize = 11f
            navBar.addView(btnExit, LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.WRAP_CONTENT))
            btnHome.setOnClickListener { sendKey("home") }
            btnBack.setOnClickListener { sendKey("back") }
            btnRecents.setOnClickListener { sendKey("recents") }
            btnExit.setOnClickListener { finish() }
            val navLp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            navLp.gravity = Gravity.BOTTOM
            root.addView(navBar, navLp)
            setupTouch()
        }

        setContentView(root)
        tvMsg.text = "Menyambung…"

        try {
            onBackPressedDispatcher.addCallback(
                this,
                object : androidx.activity.OnBackPressedCallback(true) {
                    override fun handleOnBackPressed() {
                        if (kind == "control" && camStreaming) {
                            // Di mode kontrol, tombol/gestur back milik HP utama dipakai untuk
                            // mengontrol HP kedua (bukan untuk menutup layar), persis seperti
                            // sedang benar-benar memegang HP itu.
                            sendKey("back")
                        } else {
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                            isEnabled = true
                        }
                    }
                }
            )
        } catch (e: Exception) {
            Log.e("mwahh", "addCallback back gagal, back pakai perilaku bawaan", e)
        }
    }

    // Pakai helper dari androidx.core (WindowCompat/WindowInsetsControllerCompat), bukan API
    // mentah per-versi Android -- lebih aman lintas pabrikan (MIUI, OneUI, dll). Dibungkus
    // try-catch supaya kalau pun ada ROM yang rewel, aplikasinya tidak ikut crash -- paling
    // buruk status/navigation bar tetap kelihatan, bukan tertutup paksa menampilkan error.
    private fun hideSystemBars() {
        try {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } catch (e: Exception) {
            Log.e("mwahh", "hideSystemBars gagal, dilewati", e)
        }
    }

    override fun onStart() {
        super.onStart()
        val e = EglBase.create()
        egl = e
        video.init(e.eglBaseContext, null)
        video.setEnableHardwareScaler(true)
        video.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
        sig = Signaling(this, code, { onMsg(it) }, { online ->
            sigOn = online
            if (online) {
                tvMsg.text = "Menunggu HP kedua…"
            } else {
                tvMsg.text = "Menyambung ke server…"
                powerOn = null
                camOnline = false
                camStreaming = false
                connecting = false
                startSent = false
                teardownPc()
            }
        })
        sig?.start()
    }

    override fun onStop() {
        if (camStreaming || connecting) sig?.send(Rtc.cmd("stop"))
        sig?.stop()
        sig = null
        teardownPc()
        video.release()
        egl?.release()
        egl = null
        super.onStop()
    }

    private fun maybeAutoStart() {
        if (startSent || connecting || camStreaming) return
        if (sigOn && camOnline && powerOn == true) {
            connecting = true
            startSent = true
            tvMsg.text = "Menyalakan…"
            Thread {
                val arr = fetchIceJson()
                main.post {
                    if (!connecting || sig == null) return@post
                    lastIce = arr
                    sig?.send(Rtc.cmd("start").put("ice", arr).put("kind", kind))
                }
            }.start()
        } else if (sigOn && powerOn == false) {
            tvMsg.text = "Koneksi sedang diputus.\nBuka menu, tekan Mulai, lalu coba lagi."
        } else if (sigOn && !camOnline) {
            tvMsg.text = "HP kedua offline."
        }
    }

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "power" -> {
                powerOn = j.optBoolean("on", true)
                if (powerOn == false) {
                    camStreaming = false
                    connecting = false
                    teardownPc()
                    tvMsg.text = "Koneksi diputus dari menu."
                }
            }
            "peer" -> {
                camOnline = j.optBoolean("online")
                if (!camOnline) {
                    camStreaming = false
                    connecting = false
                    startSent = false
                    teardownPc()
                    tvMsg.text = "HP kedua offline."
                }
            }
            "error" -> {
                connecting = false
                startSent = false
                tvMsg.text = j.optString("message", "Terjadi kesalahan")
                Toast.makeText(this, tvMsg.text, Toast.LENGTH_LONG).show()
            }
            "input_ack" -> {
                if (!j.optBoolean("ok", true)) {
                    Toast.makeText(this, "Sentuhan ditolak sistem di HP kedua", Toast.LENGTH_SHORT).show()
                }
            }
            "state" -> {
                camStreaming = j.optBoolean("streaming")
                remoteW = j.optInt("w", 0)
                remoteH = j.optInt("h", 0)
                if (!camStreaming) {
                    connecting = false
                    teardownPc()
                }
            }
            "offer" -> handleOffer(j.getString("sdp"))
            "ice" -> {
                try { ice.add(pc, Rtc.jsonToIce(j)) } catch (e: Exception) {}
            }
        }
        maybeAutoStart()
    }

    private fun fetchIceJson(): JSONArray {
        val fb = JSONArray().put(
            JSONObject().put("urls", JSONArray().put("stun:stun.cloudflare.com:3478"))
        )
        return try {
            val client = OkHttpClient.Builder().callTimeout(8, TimeUnit.SECONDS).build()
            val req = Request.Builder().url(Cfg.turnUrl(this)).build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) fb
                else {
                    val root = JSONObject(r.body!!.string())
                    when (val raw = root.opt("iceServers")) {
                        is JSONArray -> raw
                        is JSONObject -> JSONArray().put(raw)
                        else -> fb
                    }
                }
            }
        } catch (e: Exception) {
            fb
        }
    }

    private fun handleOffer(sdp: String) {
        teardownPc()
        try {
            answer(Rtc.toIceServers(lastIce), sdp)
        } catch (e: Exception) {
            tvMsg.text = "Gagal: ${e.message}"
        }
    }

    private fun answer(servers: List<PeerConnection.IceServer>, sdp: String) {
        val eglB = egl ?: return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .createInitializationOptions()
        )
        val adm = JavaAudioDeviceModule.builder(this).createAudioDeviceModule()
        val f = PeerConnectionFactory.builder()
            .setAudioDeviceModule(adm)
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglB.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglB.eglBaseContext))
            .createPeerConnectionFactory()
        adm.release()
        factory = f

        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = true

        val cfg = PeerConnection.RTCConfiguration(servers)
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val p = f.createPeerConnection(cfg, object : Rtc.PcObserver() {
            override fun onIceCandidate(c: IceCandidate?) {
                if (c != null) main.post { sig?.send(Rtc.iceToJson(c)) }
            }

            override fun onTrack(transceiver: RtpTransceiver?) {
                val tr = transceiver?.receiver?.track() ?: return
                main.post {
                    when (tr) {
                        is VideoTrack -> {
                            remoteVideo = tr
                            tr.addSink(video)
                            tvMsg.text = ""
                        }
                        is AudioTrack -> remoteAudio = tr
                    }
                }
            }

            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                if (s == PeerConnection.IceConnectionState.FAILED) {
                    main.post {
                        sig?.send(Rtc.cmd("stop"))
                        teardownPc()
                        camStreaming = false
                        connecting = false
                        startSent = false
                        tvMsg.text = "Video gagal tersambung (jaringan mungkin butuh TURN)."
                    }
                }
            }
        }) ?: throw IllegalStateException("peer connection gagal dibuat")
        pc = p
        ice.reset()

        p.setRemoteDescription(object : Rtc.Sdp() {
            override fun onSetSuccess() {
                main.post {
                    if (pc !== p) return@post
                    ice.flush(p)
                    p.createAnswer(object : Rtc.Sdp() {
                        override fun onCreateSuccess(d: SessionDescription?) {
                            if (d == null) return
                            p.setLocalDescription(Rtc.Sdp(), d)
                            main.post {
                                sig?.send(JSONObject().put("type", "answer").put("sdp", d.description))
                            }
                        }
                    }, MediaConstraints())
                }
            }
        }, SessionDescription(SessionDescription.Type.OFFER, sdp))
    }

    private fun teardownPc() {
        try { remoteVideo?.removeSink(video) } catch (e: Exception) {}
        remoteVideo = null
        remoteAudio = null
        try { pc?.close() } catch (e: Exception) {}
        try { pc?.dispose() } catch (e: Exception) {}
        pc = null
        try { factory?.dispose() } catch (e: Exception) {}
        factory = null
        ice.reset()
        try { video.clearImage() } catch (e: Exception) {}
        remoteW = 0
        remoteH = 0
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.isSpeakerphoneOn = false
        am.mode = AudioManager.MODE_NORMAL
    }

    // ---------- KONTROL SENTUH ----------

    private var downX = 0f
    private var downY = 0f
    private var downT = 0L

    private fun sendKey(name: String) {
        if (camStreaming) sig?.send(JSONObject().put("type", "input").put("action", "key").put("name", name))
    }

    private fun setupTouch() {
        video.setOnTouchListener { v, ev ->
            if (!camStreaming || remoteW <= 0 || remoteH <= 0) return@setOnTouchListener false
            val rx = remoteW.toFloat() / v.width.toFloat()
            val ry = remoteH.toFloat() / v.height.toFloat()
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x; downY = ev.y; downT = System.currentTimeMillis()
                }
                MotionEvent.ACTION_UP -> {
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    val dur = (System.currentTimeMillis() - downT).coerceAtLeast(30)
                    val j = JSONObject().put("type", "input")
                    if (abs(dx) < dp(16) && abs(dy) < dp(16)) {
                        j.put("action", "tap").put("x", downX * rx).put("y", downY * ry).put("dur", 60)
                    } else {
                        j.put("action", "swipe")
                            .put("x1", downX * rx).put("y1", downY * ry)
                            .put("x2", ev.x * rx).put("y2", ev.y * ry)
                            .put("dur", dur)
                    }
                    sig?.send(j)
                }
            }
            true
        }
    }
}
