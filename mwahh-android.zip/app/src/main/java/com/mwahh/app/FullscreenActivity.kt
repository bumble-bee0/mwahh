package com.mwahh.app

import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.*
import org.webrtc.audio.JavaAudioDeviceModule
import java.util.concurrent.TimeUnit

// Video kamera benar-benar memenuhi layar. Ketuk dua kali = ganti kamera depan/belakang.
// Satu-satunya tombol yang tampil adalah Bisukan, kecil di pojok, tidak menumpuk di tengah.
class FullscreenActivity : AppCompatActivity() {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var video: SurfaceViewRenderer
    private lateinit var tvMsg: TextView
    private lateinit var btnMute: Button

    private var code = ""
    private var quality = "mid"

    private var sig: Signaling? = null
    private var egl: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private val ice = IceQueue()
    private var lastIce: JSONArray? = null
    private var remoteVideo: VideoTrack? = null
    private var remoteAudio: AudioTrack? = null

    private var sigOn = false
    private var powerOn: Boolean? = null
    private var camOnline = false
    private var camStreaming = false
    private var connecting = false
    private var startSent = false
    private var startTries = 0
    private var muted = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        code = intent.getStringExtra("code") ?: ""
        quality = intent.getStringExtra("quality") ?: "mid"
        if (code.isEmpty()) {
            finish()
            return
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        volumeControlStream = AudioManager.STREAM_VOICE_CALL
        hideSystemBars()

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF000000.toInt())

        video = SurfaceViewRenderer(this)
        root.addView(video, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        tvMsg = TextView(this)
        tvMsg.setTextColor(0xFFFFFFFF.toInt())
        tvMsg.textSize = 15f
        tvMsg.gravity = Gravity.CENTER
        val msgLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        msgLp.gravity = Gravity.CENTER
        root.addView(tvMsg, msgLp)
        tvMsg.setOnClickListener {
            // Selama video belum tampil (tvMsg masih ada isinya), ketuk teks ini = batal & kembali.
            if (!camStreaming) finish()
        }

        btnMute = Button(this)
        btnMute.isAllCaps = false
        btnMute.textSize = 12f
        btnMute.setOnClickListener {
            muted = !muted
            remoteAudio?.setEnabled(!muted)
            render()
        }
        val muteLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        muteLp.gravity = Gravity.BOTTOM or Gravity.END
        muteLp.setMargins(0, 0, dp(12), dp(16))
        root.addView(btnMute, muteLp)

        setupTouch()
        setContentView(root)
        tvMsg.text = "Menyambung…"
        render()
    }

    private fun hideSystemBars() {
        try {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } catch (e: Exception) {
            Log.e("mwahh", "hideSystemBars gagal, dilewati", e)
        }
    }

    override fun onStart() {
        super.onStart()
        val e = EglBase.create()
        egl = e
        video.init(e.eglBaseContext, null)
        video.setEnableHardwareScaler(true)
        video.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
        sig = Signaling(this, code, { onMsg(it) }, { online ->
            sigOn = online
            if (online) {
                tvMsg.text = "Menunggu HP kedua…"
            } else {
                tvMsg.text = "Menyambung ke server…"
                powerOn = null
                camOnline = false
                camStreaming = false
                connecting = false
                startSent = false
                teardownPc()
            }
        })
        sig?.start()
    }

    override fun onStop() {
        main.removeCallbacks(startTimeout)
        if (camStreaming || connecting) sig?.send(Rtc.cmd("stop"))
        sig?.stop()
        sig = null
        teardownPc()
        video.release()
        egl?.release()
        egl = null
        super.onStop()
    }

    private val startTimeout = Runnable {
        if (camStreaming) return@Runnable
        startTries++
        if (startTries <= 2) {
            tvMsg.text = "Belum ada respons, mencoba lagi… (percobaan ${startTries + 1})"
            connecting = false
            startSent = false
            maybeAutoStart()
        } else {
            tvMsg.text = "HP kedua tidak merespons setelah beberapa kali dicoba.\n" +
                "Kemungkinan aplikasi Sistem Keamanan di HP kedua tertutup/mati, atau " +
                "sinyalnya sedang jelek.\n\nKetuk tulisan ini untuk kembali ke menu."
            connecting = false
        }
    }

    private fun maybeAutoStart() {
        if (startSent || connecting || camStreaming) return
        if (sigOn && camOnline && powerOn == true) {
            connecting = true
            startSent = true
            tvMsg.text = "Menyalakan…"
            main.removeCallbacks(startTimeout)
            main.postDelayed(startTimeout, 12000)
            Thread {
                val arr = fetchIceJson()
                main.post {
                    if (!connecting || sig == null) return@post
                    lastIce = arr
                    sig?.send(Rtc.cmd("start").put("ice", arr).put("kind", "cam").put("quality", quality))
                }
            }.start()
        } else if (sigOn && powerOn == false) {
            tvMsg.text = "Koneksi sedang diputus.\nBuka menu, tekan Mulai, lalu coba lagi.\n\nKetuk tulisan ini untuk kembali."
        } else if (sigOn && !camOnline) {
            tvMsg.text = "HP kedua offline.\n\nKetuk tulisan ini untuk kembali."
        }
    }

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "power" -> {
                powerOn = j.optBoolean("on", true)
                if (powerOn == false) {
                    main.removeCallbacks(startTimeout)
                    camStreaming = false
                    connecting = false
                    startSent = false
                    teardownPc()
                    tvMsg.text = "Koneksi diputus dari menu.\n\nKetuk tulisan ini untuk kembali."
                }
            }
            "peer" -> {
                camOnline = j.optBoolean("online")
                if (!camOnline) {
                    main.removeCallbacks(startTimeout)
                    camStreaming = false
                    connecting = false
                    startSent = false
                    teardownPc()
                    tvMsg.text = "HP kedua offline.\n\nKetuk tulisan ini untuk kembali."
                }
            }
            "error" -> {
                main.removeCallbacks(startTimeout)
                connecting = false
                startSent = false
                tvMsg.text = j.optString("message", "Terjadi kesalahan") + "\n\nKetuk tulisan ini untuk kembali."
                Toast.makeText(this, tvMsg.text, Toast.LENGTH_LONG).show()
            }
            "state" -> {
                camStreaming = j.optBoolean("streaming")
                if (!camStreaming) {
                    connecting = false
                    teardownPc()
                }
            }
            "offer" -> handleOffer(j.getString("sdp"))
            "ice" -> {
                try { ice.add(pc, Rtc.jsonToIce(j)) } catch (e: Exception) {}
            }
        }
        render()
        maybeAutoStart()
    }

    private fun fetchIceJson(): JSONArray {
        val fb = JSONArray().put(
            JSONObject().put("urls", JSONArray().put("stun:stun.cloudflare.com:3478"))
        )
        return try {
            val client = OkHttpClient.Builder().callTimeout(8, TimeUnit.SECONDS).build()
            val req = Request.Builder().url(Cfg.turnUrl(this)).build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) fb
                else {
                    val root = JSONObject(r.body!!.string())
                    when (val raw = root.opt("iceServers")) {
                        is JSONArray -> raw
                        is JSONObject -> JSONArray().put(raw)
                        else -> fb
                    }
                }
            }
        } catch (e: Exception) {
            fb
        }
    }

    private fun handleOffer(sdp: String) {
        teardownPc()
        try {
            answer(Rtc.toIceServers(lastIce), sdp)
        } catch (e: Exception) {
            tvMsg.text = "Gagal: ${e.message}"
        }
    }

    private fun answer(servers: List<PeerConnection.IceServer>, sdp: String) {
        val eglB = egl ?: return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .createInitializationOptions()
        )
        val adm = JavaAudioDeviceModule.builder(this).createAudioDeviceModule()
        val f = PeerConnectionFactory.builder()
            .setAudioDeviceModule(adm)
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglB.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglB.eglBaseContext))
            .createPeerConnectionFactory()
        adm.release()
        factory = f

        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = true

        val cfg = PeerConnection.RTCConfiguration(servers)
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val p = f.createPeerConnection(cfg, object : Rtc.PcObserver() {
            override fun onIceCandidate(c: IceCandidate?) {
                if (c != null) main.post { sig?.send(Rtc.iceToJson(c)) }
            }

            override fun onTrack(transceiver: RtpTransceiver?) {
                val tr = transceiver?.receiver?.track() ?: return
                main.post {
                    when (tr) {
                        is VideoTrack -> {
                            remoteVideo = tr
                            tr.addSink(video)
                            tvMsg.text = ""
                            main.removeCallbacks(startTimeout)
                            startTries = 0
                        }
                        is AudioTrack -> {
                            remoteAudio = tr
                            tr.setEnabled(!muted)
                        }
                    }
                }
            }

            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                if (s == PeerConnection.IceConnectionState.FAILED) {
                    main.post {
                        sig?.send(Rtc.cmd("stop"))
                        teardownPc()
                        camStreaming = false
                        connecting = false
                        startSent = false
                        tvMsg.text = "Video gagal tersambung (jaringan mungkin butuh TURN)."
                    }
                }
            }
        }) ?: throw IllegalStateException("peer connection gagal dibuat")
        pc = p
        ice.reset()

        p.setRemoteDescription(object : Rtc.Sdp() {
            override fun onSetSuccess() {
                main.post {
                    if (pc !== p) return@post
                    ice.flush(p)
                    p.createAnswer(object : Rtc.Sdp() {
                        override fun onCreateSuccess(d: SessionDescription?) {
                            if (d == null) return
                            p.setLocalDescription(Rtc.Sdp(), d)
                            main.post {
                                sig?.send(JSONObject().put("type", "answer").put("sdp", d.description))
                            }
                        }
                    }, MediaConstraints())
                }
            }
        }, SessionDescription(SessionDescription.Type.OFFER, sdp))
    }

    private fun teardownPc() {
        try { remoteVideo?.removeSink(video) } catch (e: Exception) {}
        remoteVideo = null
        remoteAudio = null
        try { pc?.close() } catch (e: Exception) {}
        try { pc?.dispose() } catch (e: Exception) {}
        pc = null
        try { factory?.dispose() } catch (e: Exception) {}
        factory = null
        ice.reset()
        try { video.clearImage() } catch (e: Exception) {}
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.isSpeakerphoneOn = false
        am.mode = AudioManager.MODE_NORMAL
    }

    private var downX = 0f
    private var downY = 0f

    private fun setupTouch() {
        val doubleTapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (camStreaming) {
                    sig?.send(Rtc.cmd("switch"))
                    Toast.makeText(this@FullscreenActivity, "Ganti kamera…", Toast.LENGTH_SHORT).show()
                }
                return true
            }
        })
        video.setOnTouchListener { _, ev ->
            doubleTapDetector.onTouchEvent(ev)
            true
        }
    }

    private fun render() {
        if (!::btnMute.isInitialized) return
        btnMute.text = if (muted) "Nyalakan suara" else "Bisukan"
        btnMute.visibility = if (camStreaming) android.view.View.VISIBLE else android.view.View.GONE
    }
}
