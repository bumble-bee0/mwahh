package com.mwahh.app

import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Daftar foto di HP kedua (dari galeri bawaan Android) + penampil foto penuh.
// Catatan: ini daftar nama+tanggal apa adanya (belum ada thumbnail kotak-kotak),
// dibatasi 200 foto terbaru supaya tidak berat.
class GalleryActivity : AppCompatActivity() {

    private val main = Handler(Looper.getMainLooper())
    private var code = ""
    private var sig: Signaling? = null

    private lateinit var listBox: LinearLayout
    private lateinit var tvInfo: TextView
    private lateinit var imageView: ImageView
    private lateinit var viewerBox: FrameLayout

    // id foto -> (urutan potongan -> teks base64 potongan itu)
    private val chunks = HashMap<Long, HashMap<Int, String>>()
    private val chunkTotal = HashMap<Long, Int>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        code = intent.getStringExtra("code") ?: ""
        if (code.isEmpty()) {
            finish()
            return
        }
        title = "Galeri"

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFFFFFFFF.toInt())

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(20), dp(20), dp(20))
        tvInfo = TextView(this)
        tvInfo.text = "Memuat daftar foto…"
        box.addView(tvInfo)
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        box.addView(listBox)
        val scroll = ScrollView(this)
        scroll.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        viewerBox = FrameLayout(this)
        viewerBox.setBackgroundColor(0xFF000000.toInt())
        viewerBox.visibility = View.GONE
        imageView = ImageView(this)
        imageView.scaleType = ImageView.ScaleType.FIT_CENTER
        viewerBox.addView(imageView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        viewerBox.setOnClickListener { viewerBox.visibility = View.GONE }
        root.addView(viewerBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewerBox.visibility == View.VISIBLE) {
                    viewerBox.visibility = View.GONE
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        sig = Signaling(this, code, { onMsg(it) }, { online ->
            if (online) {
                sig?.send(JSONObject().put("type", "gallery").put("action", "list"))
            } else {
                main.post { tvInfo.text = "Tidak tersambung ke HP kedua." }
            }
        })
        sig?.start()
    }

    override fun onStop() {
        sig?.stop()
        sig = null
        chunks.clear()
        chunkTotal.clear()
        super.onStop()
    }

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "gallery_list" -> renderList(j.optJSONArray("items") ?: JSONArray())
            "gallery_chunk" -> handleChunk(j)
            "gallery_error" -> main.post {
                tvInfo.text = "Ketuk nama foto untuk membuka"
                Toast.makeText(this, j.optString("message", "Gagal memuat foto"), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun renderList(items: JSONArray) {
        main.post {
            listBox.removeAllViews()
            if (items.length() == 0) {
                tvInfo.text = "Tidak ada foto ditemukan di HP kedua."
                return@post
            }
            tvInfo.text = "Ketuk nama foto untuk membuka (${items.length()} foto terbaru)"
            val fmt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale("in"))
            for (i in 0 until items.length()) {
                val o = items.getJSONObject(i)
                val id = o.optLong("id")
                val name = o.optString("name")
                val dateSec = o.optLong("date")
                val row = TextView(this)
                row.text = if (dateSec > 0) "$name\n${fmt.format(Date(dateSec * 1000L))}" else name
                row.setTypeface(null, Typeface.DEFAULT)
                row.textSize = 15f
                row.setPadding(0, dp(12), 0, dp(12))
                row.setOnClickListener {
                    tvInfo.text = "Memuat foto \"$name\"…"
                    sig?.send(JSONObject().put("type", "gallery").put("action", "full").put("id", id))
                }
                listBox.addView(row)
            }
        }
    }

    private fun handleChunk(j: JSONObject) {
        val id = j.optLong("id")
        val seq = j.optInt("seq")
        val total = j.optInt("total").coerceAtLeast(1)
        val data = j.optString("data")
        val map = chunks.getOrPut(id) { HashMap() }
        map[seq] = data
        chunkTotal[id] = total
        if (map.size < total) return

        val sb = StringBuilder()
        for (k in 0 until total) sb.append(map[k] ?: "")
        chunks.remove(id)
        chunkTotal.remove(id)

        Thread {
            try {
                val bytes = Base64.decode(sb.toString(), Base64.NO_WRAP)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                main.post {
                    tvInfo.text = "Ketuk nama foto untuk membuka"
                    if (bmp != null) {
                        imageView.setImageBitmap(bmp)
                        viewerBox.visibility = View.VISIBLE
                    } else {
                        Toast.makeText(this, "Gagal menampilkan foto", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                main.post {
                    tvInfo.text = "Ketuk nama foto untuk membuka"
                    Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }
}
