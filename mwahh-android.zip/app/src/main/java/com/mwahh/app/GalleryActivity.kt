package com.mwahh.app

import android.content.ContentValues
import android.graphics.BitmapFactory
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

// Daftar foto+video di HP kedua. Foto bisa dilihat penuh; foto/video bisa diunduh ke HP ini.
//
// Perbaikan dibanding versi sebelumnya: data unduhan yang datang bertahap (base64) langsung
// didekode dan ditulis ke berkas di galeri HP ini, tidak lagi ditumpuk semua di memori.
// Jadi video besar tidak membuat aplikasi crash. Unduhan yang tidak lengkap otomatis dihapus.
class GalleryActivity : AppCompatActivity() {

    private data class GItem(val id: Long, val name: String, val date: Long, val mtype: String)

    private class Download(val key: String, val item: GItem, val uri: Uri, val out: OutputStream) {
        val waiting = HashMap<Int, String>()
        var next = 0
        var carry = ""
        var bytes = 0L
        @Volatile var failed: String? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var code = ""
    private var sig: Signaling? = null
    private var sigOn = false

    private lateinit var listView: ListView
    private lateinit var adapter: ItemsAdapter
    private val items = ArrayList<GItem>()
    private lateinit var tvInfo: TextView
    private lateinit var viewerBox: FrameLayout
    private lateinit var imageView: ImageView

    // Penampung untuk daftar dan pratinjau foto (kecil, aman di memori).
    private val chunks = HashMap<String, HashMap<Int, String>>()
    private var viewKey: String? = null
    private var lastItem: GItem? = null

    // Unduhan yang sedang berjalan (maksimal satu).
    private var download: Download? = null

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun keyOf(id: Long, mtype: String) = "$mtype:$id"

    private fun infoText(): String =
        if (items.isEmpty()) "Tidak ada foto/video ditemukan di HP kedua."
        else "Ketuk untuk membuka (${items.size} item). Video langsung diunduh."

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        code = intent.getStringExtra("code") ?: ""
        if (code.isEmpty()) {
            finish()
            return
        }
        title = "Galeri"
        // Layar tetap menyala supaya unduhan video besar tidak terputus.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(36), dp(18), dp(0))

        val back = Ui.text(this, "‹ Kembali", 15f, Ui.ACCENT, true)
        back.setOnClickListener { finish() }
        box.addView(back)
        val head = Ui.text(this, "Galeri HP kedua", 22f, Ui.TEXT, true)
        head.setPadding(0, dp(8), 0, 0)
        box.addView(head)

        tvInfo = Ui.text(this, "Memuat daftar foto & video…", 13f, Ui.SUB)
        tvInfo.setPadding(0, dp(4), 0, dp(10))
        box.addView(tvInfo)

        // ListView hanya menggambar baris yang kelihatan, jadi tetap ringan untuk ribuan item.
        adapter = ItemsAdapter()
        listView = ListView(this)
        listView.adapter = adapter
        listView.divider = ColorDrawable(0xFFE5E7EB.toInt())
        listView.dividerHeight = 1
        listView.background = Ui.rounded(this, Ui.CARD, 14)
        listView.setOnItemClickListener { _, _, position, _ -> onItemTap(items[position]) }
        box.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        viewerBox = FrameLayout(this)
        viewerBox.setBackgroundColor(0xFF000000.toInt())
        viewerBox.visibility = View.GONE
        imageView = ImageView(this)
        imageView.scaleType = ImageView.ScaleType.FIT_CENTER
        viewerBox.addView(imageView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        imageView.setOnClickListener { viewerBox.visibility = View.GONE }

        val btnDownload = Ui.button(this, "Unduh (resolusi asli)", true)
        btnDownload.setOnClickListener { downloadCurrentView() }
        val dlLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        dlLp.gravity = Gravity.BOTTOM or Gravity.END
        dlLp.setMargins(0, 0, dp(16), dp(16))
        viewerBox.addView(btnDownload, dlLp)

        root.addView(viewerBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewerBox.visibility == View.VISIBLE) {
                    viewerBox.visibility = View.GONE
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        sig = Signaling(this, code, { onMsg(it) }, { online ->
            sigOn = online
            if (online) {
                sig?.send(JSONObject().put("type", "gallery").put("action", "list"))
            } else {
                tvInfo.text = "Tidak tersambung ke HP kedua."
            }
        })
        sig?.start()
    }

    override fun onStop() {
        // Keluar dari layar ini menghentikan unduhan; berkas yang belum lengkap dihapus.
        val d = download
        if (d != null) {
            download = null
            io.execute { abortDownload(d) }
        }
        sig?.stop()
        sig = null
        sigOn = false
        chunks.clear()
        super.onStop()
    }

    override fun onDestroy() {
        io.shutdown()
        super.onDestroy()
    }

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "gallery_chunk" -> handleChunk(j)
            "gallery_done" -> handleDone(j)
            "gallery_error" -> {
                val d = download
                if (d != null) {
                    download = null
                    io.execute { abortDownload(d) }
                }
                tvInfo.text = infoText()
                Toast.makeText(this, j.optString("message", "Gagal memuat"), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun renderList(arr: JSONArray) {
        items.clear()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            items.add(GItem(o.optLong("id"), o.optString("name"), o.optLong("date"), o.optString("mtype", "image")))
        }
        adapter.notifyDataSetChanged()
        tvInfo.text = infoText()
    }

    private inner class ItemsAdapter : BaseAdapter() {
        private val fmt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale("in"))
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = items[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@GalleryActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(12), dp(16), dp(12))
                addView(Ui.text(this@GalleryActivity, "", 15f, Ui.TEXT, true))
                addView(Ui.text(this@GalleryActivity, "", 12f, Ui.SUB))
            }
            val item = items[position]
            val t1 = row.getChildAt(0) as TextView
            val t2 = row.getChildAt(1) as TextView
            t1.text = (if (item.mtype == "video") "[Video] " else "") + item.name
            t2.text = if (item.date > 0) fmt.format(Date(item.date * 1000L)) else ""
            t2.visibility = if (item.date > 0) View.VISIBLE else View.GONE
            return row
        }
    }

    private fun onItemTap(item: GItem) {
        if (download != null) {
            Toast.makeText(this, "Masih ada unduhan yang berjalan", Toast.LENGTH_SHORT).show()
            return
        }
        if (!sigOn) {
            Toast.makeText(this, "Tidak tersambung ke HP kedua", Toast.LENGTH_SHORT).show()
            return
        }
        lastItem = item
        if (item.mtype == "video") {
            AlertDialog.Builder(this)
                .setTitle("Unduh video?")
                .setMessage("\"${item.name}\" akan diunduh ke HP ini. Bisa memakan waktu dan kuota. Tetap di layar ini sampai selesai.")
                .setPositiveButton("Unduh") { _, _ -> startDownload(item, "full") }
                .setNegativeButton("Batal", null)
                .show()
        } else {
            val key = keyOf(item.id, item.mtype)
            viewKey = key
            chunks.clear()
            tvInfo.text = "Memuat foto \"${item.name}\"…"
            sig?.send(JSONObject().put("type", "gallery").put("action", "full").put("id", item.id).put("mtype", item.mtype))
        }
    }

    private fun downloadCurrentView() {
        val item = lastItem ?: return
        if (item.mtype == "video") return
        if (download != null) {
            Toast.makeText(this, "Masih ada unduhan yang berjalan", Toast.LENGTH_SHORT).show()
            return
        }
        // Yang dilihat tadi resolusi kecil; untuk unduhan minta berkas aslinya.
        startDownload(item, "original")
    }

    // Siapkan berkas tujuan di galeri HP ini, lalu minta datanya ke HP kedua.
    private fun startDownload(item: GItem, action: String) {
        if (!sigOn) {
            Toast.makeText(this, "Tidak tersambung ke HP kedua", Toast.LENGTH_SHORT).show()
            return
        }
        val isVideo = item.mtype == "video"
        val collection = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val ext = item.name.substringAfterLast('.', if (isVideo) "mp4" else "jpg")
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: if (isVideo) "video/mp4" else "image/jpeg"
        val displayName = item.name.ifEmpty { "mwahh_${System.currentTimeMillis()}.$ext" }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, if (isVideo) "Movies/mwahh" else "Pictures/mwahh")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val uri: Uri? = try { contentResolver.insert(collection, values) } catch (e: Exception) { null }
        val out: OutputStream? = if (uri != null) {
            try { contentResolver.openOutputStream(uri) } catch (e: Exception) { null }
        } else null
        if (uri == null || out == null) {
            if (uri != null) {
                try { contentResolver.delete(uri, null, null) } catch (e: Exception) {}
            }
            Toast.makeText(this, "Gagal menyiapkan berkas di galeri HP ini", Toast.LENGTH_LONG).show()
            return
        }
        download = Download(keyOf(item.id, item.mtype), item.copy(name = displayName), uri, out)
        chunks.clear()
        tvInfo.text = "Mengunduh \"$displayName\"…"
        sig?.send(JSONObject().put("type", "gallery").put("action", action).put("id", item.id).put("mtype", item.mtype))
    }

    private fun handleChunk(j: JSONObject) {
        val key = keyOf(j.optLong("id"), j.optString("mtype"))
        val seq = j.optInt("seq")
        val data = j.optString("data")
        val d = download
        if (d != null && d.key == key) {
            io.execute { feed(d, seq, data) }
            return
        }
        chunks.getOrPut(key) { HashMap() }[seq] = data
    }

    // Jalan di thread io (berurutan). Dekode setiap potongan, tulis langsung ke berkas.
    private fun feed(d: Download, seq: Int, data: String) {
        if (d.failed != null) return
        d.waiting[seq] = data
        try {
            while (true) {
                val part = d.waiting.remove(d.next) ?: break
                val s = d.carry + part.replace("\n", "").replace("\r", "")
                val usable = s.length - (s.length % 4)
                if (usable > 0) {
                    val bytes = Base64.decode(s.substring(0, usable), Base64.NO_WRAP)
                    d.out.write(bytes)
                    d.bytes += bytes.size
                }
                d.carry = s.substring(usable)
                d.next++
            }
        } catch (e: Exception) {
            d.failed = e.message ?: "gagal menulis berkas"
            return
        }
        val mb = d.bytes / 1048576.0
        main.post {
            if (download === d) {
                tvInfo.text = "Mengunduh \"${d.item.name}\"… " + String.format(Locale.US, "%.1f", mb) + " MB"
            }
        }
    }

    private fun finishDownload(d: Download, total: Int) {
        var err: String? = d.failed
        if (err == null) {
            try {
                if (d.carry.isNotEmpty()) {
                    val bytes = Base64.decode(d.carry, Base64.NO_WRAP)
                    d.out.write(bytes)
                    d.bytes += bytes.size
                    d.carry = ""
                }
                if (d.next != total) err = "data tidak lengkap (${d.next} dari $total bagian)"
            } catch (e: Exception) {
                err = e.message ?: "gagal menulis berkas"
            }
        }
        try {
            d.out.close()
        } catch (e: Exception) {
            if (err == null) err = "gagal menutup berkas"
        }
        if (err != null) {
            try { contentResolver.delete(d.uri, null, null) } catch (e: Exception) {}
        } else if (Build.VERSION.SDK_INT >= 29) {
            try {
                val v = ContentValues()
                v.put(MediaStore.MediaColumns.IS_PENDING, 0)
                contentResolver.update(d.uri, v, null, null)
            } catch (e: Exception) {}
        }
        val finalErr = err
        main.post {
            if (download === d) download = null
            tvInfo.text = infoText()
            if (finalErr != null) {
                Toast.makeText(this, "Unduhan gagal: $finalErr", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Tersimpan di galeri HP ini: ${d.item.name}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun abortDownload(d: Download) {
        d.failed = "dibatalkan"
        try { d.out.close() } catch (e: Exception) {}
        try { contentResolver.delete(d.uri, null, null) } catch (e: Exception) {}
    }

    private fun handleDone(j: JSONObject) {
        val id = j.optLong("id")
        val mtype = j.optString("mtype")
        val key = keyOf(id, mtype)
        val total = j.optInt("total")

        val d = download
        if (d != null && d.key == key) {
            io.execute { finishDownload(d, total) }
            return
        }

        val map = chunks.remove(key) ?: HashMap()

        // Daftar galeri datang dipotong-potong juga, ditandai mtype "__list__".
        if (mtype == "__list__") {
            Thread {
                try {
                    val sb = StringBuilder()
                    for (k in 0 until total) sb.append(map[k] ?: "")
                    val bytes = Base64.decode(sb.toString(), Base64.NO_WRAP)
                    val arr = JSONArray(String(bytes, Charsets.UTF_8))
                    main.post { renderList(arr) }
                } catch (e: Exception) {
                    main.post { tvInfo.text = "Gagal memuat daftar: ${e.message}" }
                }
            }.start()
            return
        }

        // Pratinjau foto (resolusi kecil).
        if (viewKey != key) return
        Thread {
            try {
                val sb = StringBuilder()
                for (k in 0 until total) sb.append(map[k] ?: "")
                val bytes = Base64.decode(sb.toString(), Base64.NO_WRAP)
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                main.post {
                    tvInfo.text = infoText()
                    if (bmp != null) {
                        imageView.setImageBitmap(bmp)
                        viewerBox.visibility = View.VISIBLE
                    } else {
                        Toast.makeText(this, "Gagal menampilkan foto", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                main.post {
                    tvInfo.text = infoText()
                    Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }
}
