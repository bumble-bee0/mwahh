package com.mwahh.app

import android.content.ContentValues
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Daftar nama foto+video (seluruh isi galeri HP kedua) + penampil foto penuh + unduh.
// Video tidak dipratonton di dalam aplikasi, cukup diunduh lalu dibuka lewat galeri/pemutar
// video biasa di HP utama -- keputusan sadar supaya ringan dan render-nya cepat.
class GalleryActivity : AppCompatActivity() {

    private data class GItem(val id: Long, val name: String, val date: Long, val mtype: String)

    private val main = Handler(Looper.getMainLooper())
    private var code = ""
    private var sig: Signaling? = null

    private lateinit var listView: ListView
    private lateinit var adapter: ItemsAdapter
    private val items = ArrayList<GItem>()
    private lateinit var tvInfo: TextView
    private lateinit var viewerBox: FrameLayout
    private lateinit var imageView: ImageView
    private lateinit var btnDownload: Button

    private val chunks = HashMap<String, HashMap<Int, String>>()
    private var pendingKey: String? = null
    private var pendingIsDownload = false
    private var lastItem: GItem? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun keyOf(id: Long, mtype: String) = "$mtype:$id"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        code = intent.getStringExtra("code") ?: ""
        if (code.isEmpty()) {
            finish()
            return
        }
        title = "Galeri"

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFFFFFFFF.toInt())

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        tvInfo = TextView(this)
        tvInfo.text = "Memuat daftar foto & video…"
        tvInfo.setPadding(dp(20), dp(20), dp(20), dp(8))
        box.addView(tvInfo)

        // ListView mendaur ulang baris yang sudah di luar layar (cuma menggambar yang
        // kelihatan), jadi tetap ringan walau isinya ribuan item -- beda dengan menumpuk
        // semua baris sekaligus di satu LinearLayout panjang seperti sebelumnya.
        adapter = ItemsAdapter()
        listView = ListView(this)
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ -> onItemTap(items[position]) }
        box.addView(listView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        root.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        viewerBox = FrameLayout(this)
        viewerBox.setBackgroundColor(0xFF000000.toInt())
        viewerBox.visibility = View.GONE
        imageView = ImageView(this)
        imageView.scaleType = ImageView.ScaleType.FIT_CENTER
        viewerBox.addView(imageView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        imageView.setOnClickListener { viewerBox.visibility = View.GONE }

        btnDownload = Button(this)
        btnDownload.text = "Unduh"
        btnDownload.isAllCaps = false
        btnDownload.setOnClickListener { downloadCurrentView() }
        val dlLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        dlLp.gravity = Gravity.BOTTOM or Gravity.END
        dlLp.setMargins(0, 0, dp(16), dp(16))
        viewerBox.addView(btnDownload, dlLp)

        root.addView(viewerBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewerBox.visibility == View.VISIBLE) {
                    viewerBox.visibility = View.GONE
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        sig = Signaling(this, code, { onMsg(it) }, { online ->
            if (online) {
                sig?.send(JSONObject().put("type", "gallery").put("action", "list"))
            } else {
                main.post { tvInfo.text = "Tidak tersambung ke HP kedua." }
            }
        })
        sig?.start()
    }

    override fun onStop() {
        sig?.stop()
        sig = null
        chunks.clear()
        super.onStop()
    }

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "gallery_chunk" -> handleChunk(j)
            "gallery_done" -> handleDone(j)
            "gallery_error" -> main.post {
                tvInfo.text = "Ketuk nama untuk membuka"
                Toast.makeText(this, j.optString("message", "Gagal memuat"), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun renderList(arr: JSONArray) {
        main.post {
            items.clear()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(GItem(o.optLong("id"), o.optString("name"), o.optLong("date"), o.optString("mtype", "image")))
            }
            adapter.notifyDataSetChanged()
            tvInfo.text = if (items.isEmpty())
                "Tidak ada foto/video ditemukan di HP kedua."
            else
                "Ketuk nama untuk membuka (${items.size} item)"
        }
    }

    private inner class ItemsAdapter : BaseAdapter() {
        private val fmt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale("in"))
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = items[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? TextView) ?: TextView(this@GalleryActivity).apply {
                textSize = 15f
                setPadding(dp(20), dp(12), dp(20), dp(12))
            }
            val item = items[position]
            val tag = if (item.mtype == "video") "[Video] " else ""
            row.text = if (item.date > 0) "$tag${item.name}\n${fmt.format(Date(item.date * 1000L))}" else "$tag${item.name}"
            return row
        }
    }

    private fun onItemTap(item: GItem) {
        lastItem = item
        pendingKey = keyOf(item.id, item.mtype)
        if (item.mtype == "video") {
            pendingIsDownload = true
            tvInfo.text = "Mengunduh video \"${item.name}\"… bisa makan waktu & kuota"
            Toast.makeText(this, "Mengunduh video, mohon tunggu…", Toast.LENGTH_SHORT).show()
        } else {
            pendingIsDownload = false
            tvInfo.text = "Memuat foto \"${item.name}\"…"
        }
        sig?.send(JSONObject().put("type", "gallery").put("action", "full").put("id", item.id).put("mtype", item.mtype))
    }

    private fun downloadCurrentView() {
        val item = lastItem ?: return
        if (item.mtype == "video") return // video sudah otomatis diunduh resolusi asli saat diketuk
        // Yang sedang dilihat ini resolusi kecil (cepat dimuat). Untuk unduhan, minta ULANG
        // ke HP kedua dalam bentuk "original" -- berkas asli, resolusi/kualitas penuh.
        pendingKey = keyOf(item.id, item.mtype)
        pendingIsDownload = true
        tvInfo.text = "Mengunduh \"${item.name}\" (resolusi asli)…"
        Toast.makeText(this, "Mengunduh resolusi asli…", Toast.LENGTH_SHORT).show()
        sig?.send(JSONObject().put("type", "gallery").put("action", "original").put("id", item.id).put("mtype", item.mtype))
    }

    private fun handleChunk(j: JSONObject) {
        val key = keyOf(j.optLong("id"), j.optString("mtype"))
        chunks.getOrPut(key) { HashMap() }[j.optInt("seq")] = j.optString("data")
    }

    private fun handleDone(j: JSONObject) {
        val id = j.optLong("id")
        val mtype = j.optString("mtype")
        val key = keyOf(id, mtype)
        val total = j.optInt("total")
        val map = chunks.remove(key) ?: HashMap()

        // Daftar galeri sekarang juga datang dipotong-potong (lihat catatan di CameraService),
        // ditandai dengan mtype "__list__" -- bukan foto/video, jadi ditangani terpisah di sini:
        // disusun ulang jadi teks JSON, lalu diproses sebagai daftar nama seperti biasa.
        if (mtype == "__list__") {
            Thread {
                try {
                    val sb = StringBuilder()
                    for (k in 0 until total) sb.append(map[k] ?: "")
                    val bytes = Base64.decode(sb.toString(), Base64.NO_WRAP)
                    val text = String(bytes, Charsets.UTF_8)
                    val arr = JSONArray(text)
                    renderList(arr)
                } catch (e: Exception) {
                    main.post { tvInfo.text = "Gagal memuat daftar: ${e.message}" }
                }
            }.start()
            return
        }

        val isDownload = pendingIsDownload && pendingKey == key
        val isView = !pendingIsDownload && pendingKey == key
        if (!isDownload && !isView) return

        Thread {
            try {
                val sb = StringBuilder()
                for (k in 0 until total) sb.append(map[k] ?: "")
                val bytes = Base64.decode(sb.toString(), Base64.NO_WRAP)
                main.post {
                    tvInfo.text = "Ketuk nama untuk membuka"
                    if (isDownload) {
                        val item = lastItem
                        if (item != null) saveToDeviceGallery(item, bytes)
                    } else {
                        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bmp != null) {
                            imageView.setImageBitmap(bmp)
                            viewerBox.visibility = View.VISIBLE
                        } else {
                            Toast.makeText(this, "Gagal menampilkan foto", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } catch (e: Exception) {
                main.post {
                    tvInfo.text = "Ketuk nama untuk membuka"
                    Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun saveToDeviceGallery(item: GItem, bytes: ByteArray) {
        try {
            val isVideo = item.mtype == "video"
            val collection = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val ext = item.name.substringAfterLast('.', if (isVideo) "mp4" else "jpg")
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                ?: if (isVideo) "video/mp4" else "image/jpeg"
            val displayName = item.name.ifEmpty { "mwahh_${System.currentTimeMillis()}.$ext" }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                if (Build.VERSION.SDK_INT >= 29) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, if (isVideo) "Movies/mwahh" else "Pictures/mwahh")
                }
            }
            val uri = contentResolver.insert(collection, values)
            if (uri == null) {
                Toast.makeText(this, "Gagal menyimpan ke galeri HP ini", Toast.LENGTH_SHORT).show()
                return
            }
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            Toast.makeText(this, "Tersimpan di galeri HP ini: $displayName", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menyimpan: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
