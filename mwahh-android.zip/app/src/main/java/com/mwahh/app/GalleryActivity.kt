package com.mwahh.app

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Grid foto+video asli (seperti galeri biasa), dengan penampil foto penuh + unduh ke HP ini.
// Video tidak ditampilkan di dalam aplikasi (butuh lebih banyak kerja) -- tapi tetap bisa
// diunduh, tersimpan ke galeri HP utama, baru dibuka lewat aplikasi galeri/pemutar video biasa.
class GalleryActivity : AppCompatActivity() {

    private data class GItem(val id: Long, val name: String, val date: Long, val size: Long, val mtype: String) {
        var thumb: Bitmap? = null
        var thumbAsked = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var code = ""
    private var sig: Signaling? = null

    private val items = ArrayList<GItem>()
    private lateinit var adapter: GridAdapter
    private lateinit var grid: GridView
    private lateinit var tvInfo: TextView

    private lateinit var viewerBox: FrameLayout
    private lateinit var imageView: ImageView
    private lateinit var btnDownload: Button

    // potongan yang sedang dikumpulkan, per id "mtype:id"
    private val chunks = HashMap<String, HashMap<Int, String>>()
    private var pendingKey: String? = null // item yang sedang diminta full-nya (view atau unduh)
    private var pendingIsDownload = false
    private var lastViewed: GItem? = null
    private var lastViewedBytes: ByteArray? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun keyOf(id: Long, mtype: String) = "$mtype:$id"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        code = intent.getStringExtra("code") ?: ""
        if (code.isEmpty()) {
            finish()
            return
        }
        title = "Galeri"

        val root = FrameLayout(this)
        root.setBackgroundColor(0xFFFFFFFF.toInt())

        val box = android.widget.LinearLayout(this)
        box.orientation = android.widget.LinearLayout.VERTICAL
        tvInfo = TextView(this)
        tvInfo.text = "Memuat daftar foto & video…"
        tvInfo.setPadding(dp(16), dp(16), dp(16), dp(8))
        box.addView(tvInfo)

        adapter = GridAdapter()
        grid = GridView(this)
        grid.adapter = adapter
        grid.numColumns = 3
        grid.verticalSpacing = dp(2)
        grid.horizontalSpacing = dp(2)
        grid.setPadding(dp(2), dp(2), dp(2), dp(2))
        box.addView(grid, android.widget.LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        root.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        viewerBox = FrameLayout(this)
        viewerBox.setBackgroundColor(0xFF000000.toInt())
        viewerBox.visibility = View.GONE
        imageView = ImageView(this)
        imageView.scaleType = ImageView.ScaleType.FIT_CENTER
        viewerBox.addView(imageView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        imageView.setOnClickListener { viewerBox.visibility = View.GONE }

        btnDownload = Button(this)
        btnDownload.text = "Unduh ke HP ini"
        btnDownload.isAllCaps = false
        btnDownload.setOnClickListener { downloadCurrentView() }
        val dlLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        dlLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        dlLp.setMargins(0, 0, 0, dp(24))
        viewerBox.addView(btnDownload, dlLp)

        root.addView(viewerBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        grid.setOnItemClickListener { _, _, position, _ -> onItemTap(items[position]) }

        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewerBox.visibility == View.VISIBLE) {
                    viewerBox.visibility = View.GONE
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        sig = Signaling(this, code, { onMsg(it) }, { online ->
            if (online) {
                sig?.send(JSONObject().put("type", "gallery").put("action", "list"))
            } else {
                main.post { tvInfo.text = "Tidak tersambung ke HP kedua." }
            }
        })
        sig?.start()
    }

    override fun onStop() {
        sig?.stop()
        sig = null
        chunks.clear()
        super.onStop()
    }

    private fun onItemTap(item: GItem) {
        if (item.mtype == "video") {
            Toast.makeText(this, "Mengunduh video \"${item.name}\"… bisa makan waktu & kuota", Toast.LENGTH_LONG).show()
            tvInfo.text = "Mengunduh video \"${item.name}\"…"
            pendingKey = keyOf(item.id, item.mtype)
            pendingIsDownload = true
            lastViewed = item
            sig?.send(JSONObject().put("type", "gallery").put("action", "full").put("id", item.id).put("mtype", item.mtype))
        } else {
            tvInfo.text = "Memuat foto \"${item.name}\"…"
            pendingKey = keyOf(item.id, item.mtype)
            pendingIsDownload = false
            lastViewed = item
            sig?.send(JSONObject().put("type", "gallery").put("action", "full").put("id", item.id).put("mtype", item.mtype))
        }
    }

    private fun downloadCurrentView() {
        val item = lastViewed ?: return
        val bytes = lastViewedBytes ?: return
        saveToDeviceGallery(item, bytes)
    }

    private fun onMsg(j: JSONObject) {
        when (j.optString("type")) {
            "gallery_list" -> renderList(j.optJSONArray("items") ?: JSONArray())
            "gallery_thumb" -> handleThumb(j)
            "gallery_chunk" -> handleChunk(j)
            "gallery_done" -> handleDone(j)
            "gallery_error" -> main.post {
                // Kalau ini gagal untuk salah satu thumbnail yang sedang diminta, jangan sampai
                // antreannya macet -- tetap dianggap "selesai" (gagal) lalu lanjut minta berikutnya.
                val id = j.optLong("id")
                val wasThumb = items.any { it.id == id && it.thumbAsked && it.thumb == null }
                if (wasThumb && thumbInFlight > 0) {
                    thumbInFlight--
                    requestNextThumb()
                } else {
                    Toast.makeText(this, j.optString("message", "Gagal memuat"), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun renderList(arr: JSONArray) {
        main.post {
            items.clear()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(GItem(o.optLong("id"), o.optString("name"), o.optLong("date"), o.optLong("size"), o.optString("mtype", "image")))
            }
            adapter.notifyDataSetChanged()
            tvInfo.text = if (items.isEmpty()) "Tidak ada foto/video ditemukan di HP kedua." else "Memuat ${items.size} thumbnail…"
            requestNextThumb()
        }
    }

    // Diminta beberapa sekaligus (bukan satu-satu dan tunggu balasannya baru minta lagi)
    // supaya tidak kebuang waktu nunggu bolak-balik jaringan tiap satu gambar. Dijaga tetap
    // ada beberapa yang "berjalan" (inFlight) -- begitu satu balasan datang, langsung minta
    // satu lagi, bukan menunggu semua yang sedang jalan selesai dulu.
    private var thumbInFlight = 0
    private val thumbWindow = 8

    private fun requestNextThumb() {
        while (thumbInFlight < thumbWindow) {
            val next = items.firstOrNull { !it.thumbAsked } ?: break
            next.thumbAsked = true
            thumbInFlight++
            sig?.send(JSONObject().put("type", "gallery").put("action", "thumb").put("id", next.id).put("mtype", next.mtype))
        }
        if (items.all { it.thumbAsked } && thumbInFlight == 0) {
            tvInfo.text = "${items.size} foto & video"
        }
    }

    private fun handleThumb(j: JSONObject) {
        val id = j.optLong("id")
        val mtype = j.optString("mtype")
        val data = j.optString("data")
        Thread {
            val bytes = try { Base64.decode(data, Base64.NO_WRAP) } catch (e: Exception) { null }
            val bmp = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
            main.post {
                val item = items.find { it.id == id && it.mtype == mtype }
                if (item != null) {
                    item.thumb = bmp
                    adapter.notifyDataSetChanged()
                }
                if (thumbInFlight > 0) thumbInFlight--
                requestNextThumb()
            }
        }.start()
    }

    private fun handleChunk(j: JSONObject) {
        val id = j.optLong("id")
        val mtype = j.optString("mtype")
        val key = keyOf(id, mtype)
        val seq = j.optInt("seq")
        val data = j.optString("data")
        chunks.getOrPut(key) { HashMap() }[seq] = data
    }

    private fun handleDone(j: JSONObject) {
        val id = j.optLong("id")
        val mtype = j.optString("mtype")
        val key = keyOf(id, mtype)
        val total = j.optInt("total")
        val map = chunks.remove(key) ?: HashMap()
        val isDownload = pendingIsDownload && pendingKey == key
        val isView = !pendingIsDownload && pendingKey == key
        if (!isDownload && !isView) return

        Thread {
            try {
                val sb = StringBuilder()
                for (k in 0 until total) sb.append(map[k] ?: "")
                val bytes = Base64.decode(sb.toString(), Base64.NO_WRAP)
                main.post {
                    if (isDownload) {
                        val item = lastViewed
                        if (item != null) saveToDeviceGallery(item, bytes)
                    } else {
                        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        tvInfo.text = "${items.size} foto & video"
                        if (bmp != null) {
                            lastViewedBytes = bytes
                            imageView.setImageBitmap(bmp)
                            viewerBox.visibility = View.VISIBLE
                        } else {
                            Toast.makeText(this, "Gagal menampilkan foto", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } catch (e: Exception) {
                main.post {
                    tvInfo.text = "${items.size} foto & video"
                    Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun saveToDeviceGallery(item: GItem, bytes: ByteArray) {
        try {
            val isVideo = item.mtype == "video"
            val collection = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val ext = item.name.substringAfterLast('.', if (isVideo) "mp4" else "jpg")
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                ?: if (isVideo) "video/mp4" else "image/jpeg"
            val displayName = item.name.ifEmpty { "mwahh_${System.currentTimeMillis()}.$ext" }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                if (Build.VERSION.SDK_INT >= 29) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, if (isVideo) "Movies/mwahh" else "Pictures/mwahh")
                }
            }
            val uri = contentResolver.insert(collection, values)
            if (uri == null) {
                Toast.makeText(this, "Gagal menyimpan ke galeri HP ini", Toast.LENGTH_SHORT).show()
                return
            }
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            Toast.makeText(this, "Tersimpan di galeri HP ini: $displayName", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menyimpan: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private inner class GridAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = items[position].id

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val cellSize = dp(100)
            val frame: FrameLayout
            val img: ImageView
            val badge: TextView
            if (convertView is FrameLayout) {
                frame = convertView
                img = frame.getChildAt(0) as ImageView
                badge = frame.getChildAt(1) as TextView
            } else {
                frame = FrameLayout(this@GalleryActivity)
                img = ImageView(this@GalleryActivity)
                img.scaleType = ImageView.ScaleType.CENTER_CROP
                img.setBackgroundColor(0xFFE0E0E0.toInt())
                frame.addView(img, FrameLayout.LayoutParams(cellSize, cellSize))
                badge = TextView(this@GalleryActivity)
                badge.text = "\u25B6"
                badge.setTextColor(0xFFFFFFFF.toInt())
                badge.textSize = 14f
                val bLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                bLp.gravity = Gravity.BOTTOM or Gravity.START
                bLp.setMargins(dp(4), 0, 0, dp(4))
                badge.setPadding(dp(4), 0, dp(4), 0)
                frame.addView(badge, bLp)
            }
            val item = items[position]
            val thumb = item.thumb
            if (thumb != null) img.setImageBitmap(thumb) else img.setImageDrawable(null)
            badge.visibility = if (item.mtype == "video") View.VISIBLE else View.GONE
            return frame
        }
    }
}
